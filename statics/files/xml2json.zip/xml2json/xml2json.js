/**
 * Copyright (c) 2006, Yusuke Inuzuka<yuin@inforno.net>(http://inforno.net)
 *
 * License :
 *   Articstic License 2.0
 *
 * XML2JSON :
 *   This library is a utility for XML2JSON service(http://www.drk7.jp/MT/archives/001011.html)
 *
 * Description : 
 *
 *   XML2JSON provides easy way to use XML2JSON service.
 *   By using Lyase.View, you can customize your design.
 *
 * Usage and examples :
 *
 *   //initialize
 *   Event.observe(window, "load", function(){
 *     new XML2JSON("http://feeds.feedburner.com/Inforno", 
 *       {container: "test", template : {element:"template"}});
 *   });
 *
 *  //template
 *  <div id="test">
 *  <textarea id="template" style="display:none;">
 *    <h3> <%= context.channel.title %> </h3>
 *    <ul class="items">
 *      <% context.channel.item.each(function(item,index){%>
 *        <li><a href="<%= item.link%>" target="_blank"><%= item.title%></a></li>
 *        <% if(index > 5){throw $break;}%>
 *      <%})%>
 *    </ul>
 *  </textarea>
 *  </div>
 */
var XML2JSON = Class.create();
Object.extend(XML2JSON, {
  id : 0,
  instance : {},
  proxy : 'http://app.drk7.jp/xml2json/'
});
Object.extend(XML2JSON.prototype, {
  initialize : function(url, options, params) {
    if(!url) return;
    var klass = XML2JSON;
    this.id = klass.id++;
    this.url = url;
    this.options = Object.extend({
      onload : this.onload.bind(this),
      charset : "UTF-8",
      container : null,
      template  : null
    }, options || {});
    this.params  = params ? $H(params) : null;
    klass.instance[this.id] = this;
    this.sendRequest();
  },

  sendRequest : function() {
    var script = document.createElement('script');
    script.charset = this.options.charset;
    var src = [XML2JSON.proxy, '&var=XML2JSON.instance[',this.id,'].options&url=',
               encodeURIComponent(this.url)];
    if(this.params) src.push('?'+this.params.toQueryString());
    script.src = src.join("");
    document.body.appendChild(script);
  },

  onload : function(data) {
    var options = this.options;
    if(!options.template || !options.container) return ;
    $(options.container).innerHTML = Lyase.View.render(options.template ,data);
  }
});
