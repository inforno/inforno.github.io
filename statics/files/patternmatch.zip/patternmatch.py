# vim: fileencoding=utf8
# patternmatch - Functional pattern matching for Python.
# Copyright (c) 2008, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Artistic License 2.0
#
__author__  = u"Yusuke Inuzuka"
__version__ = u"0.1"
__date__    = u"2008-12-11"

# Match {{{
class Match(object):
  """
  Functional pattern matching for Python.

  You can use pattern variables and guard expressions.
    >>> from patternmatch import Match
    >>> m = Match([1,2,3]) 
    >>> if m.when([1,2,m.var]) and m.var > 2:
    ...   m.var
    3

  Alternative as a 'switch' statements.
    >>> m = Match(10)
    >>> if m(9):
    ...   1
    ... elif m(10):
    ...   2
    ... else:
    ...   False
    2

  You can bind PATTERN to a pattern variable NAME with a m._as_`NAME`(PATTERN). (a.k.a 'as pattern')
    >>> m = Match([1,2,3]) 
    >>> if m.when([1,2,m.var]) and m.var > 5:
    ...   False
    ... elif m.when(m._as_all([1,2,m.var])):
    ...   pass
    ... else:
    ...   raise StandardError("")

    >>> m.all
    [1, 2, 3]

    >>> m.var
    3

  A pattern variable that starts with '__', holds rest of list object.
    >>> m = Match([1,2,3])
    >>> if m.when([1, m.__rest]):
    ...   m.__rest
    ... else:
    ...   False
    [2, 3]

  Class pattern matching.
  m._class takes a class object as the 1st argument,
  and a dict object as the 2nd argument, it represents obj.__dict__.
    >>> class Test(object):
    ...   def __init__(self, v1, v2):
    ...     self.v1 = v1
    ...     self.v2 = v2
    ...   def __repr__(self):
    ...     return "Test(%s, %s)"%(repr(self.v1), repr(self.v2))
    >>> m = Match([1, Test(2, 3)])
    >>> if m.when([1, m._class(Test, {"v1":2, "v2": m.v2})]):
    ...   m.v2
    ... else:
    ...   False
    3

  And, you can customize a class matching behaviour by defining the `__match__` method.
    >>> class Test2(Test):
    ...   def __match__(self):
    ...     return {"value": self.v1 + self.v2}
    >>> m = Match([1, 2, Test2(3,4)])
    >>> if m.when([1,2, m._class(Test2, {"value": m.var})]):
    ...   m.var
    ... else:
    ...   False
    7

  More complex example.
    >>> m = Match(["a", 2, [3, 4, 5, 6], Test(7, [8, 9, 10]), 11, "12"])
    >>> if m.when(["a", m.var1, [3, m.__rest1], m._as_test_obj(m._class(Test, {"v1": 7, "v2":[8, m.__rest2]})), m.var2, "12"]):
    ...   m.var1
    2

    >>> m.__rest1
    [4, 5, 6]

    >>> m.__rest2
    [9, 10]

    >>> m.var2
    11

    >>> m.test_obj
    Test(7, [8, 9, 10])

  """
  class _var(str): pass
  class _class(object):
    def __init__(self, klass, attrs):
      self.klass= klass
      self.attrs= sorted(attrs.iteritems())
    def match(self, m, obj):
      props = getattr(obj, "__match__", lambda: obj.__dict__)()
      return issubclass(obj.__class__, self.klass) and \
             m.when(self.attrs, sorted(props.iteritems()))
  class _as(object):
    def __init__(self, name, pattern = None):
      self.name = name
      self.pattern = pattern
    def __call__(self, pattern):
      self.pattern = pattern
      return self
      
  def __init__(self, obj):
    self.obj = obj
    self.bind = {}

  def __getitem__(self, key):
    if not self.bind.has_key(key):
      if key.startswith("_as_"):
        return self._as(self._var(key[4:]))
      return self._var(key)
    return self.bind[key]
  __getattr__ = __getitem__
  __call__ = lambda self, *a, **k : self.when(*a, **k)

  def when(self, pattern, obj = None):
    if not obj: obj = self.obj
    if isinstance(pattern, (self._var, self._class, self._as)):
      if isinstance(obj, (list, tuple)):
        pattern = [pattern]
        obj     = [obj]

    if not isinstance(obj, (list, tuple)) and \
       not isinstance(pattern, (list, tuple)) :
      obj = [obj]
      pattern = [pattern]

    if not isinstance(obj, (list, tuple)) or  \
       not isinstance(pattern, (list, tuple)) :
       self.bind = {}
       return False

    if len(obj) != len(pattern):
      if not ((pattern[-1].__class__ == self._var) and pattern[-1].startswith("__")):
        self.bind = {}
        return False

    for i, (value, pat) in enumerate(zip(obj, pattern)):
      if value == pat:
        continue
      elif pat.__class__ == self._var and pat.startswith("__"): 
        self.bind[str(pat)] = obj[i:]
        return True
      elif pat.__class__ == self._var:
        self.bind[str(pat)] = value
      elif pat.__class__ == self._class:
        if not pat.match(self, value):
          self.bind ={}
          return False
      elif pat.__class__ == self._as:
        if not self.when(pat.pattern, value):
          self.bind ={}
          return False
        self.bind[str(pat.name)] = value
      elif isinstance(value, (list, tuple)) and isinstance(pat, (list,tuple)):
        if not self.when(pat, value):
          self.bind = {}
          return False
      else:
        self.bind = {}
        return False

    return True
#}}} 

if __name__ == "__main__":
  import doctest
  doctest.testmod()
