# vim: fileencoding=utf-8
# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#

from struct import * 
from array import array

MASKS = map(lambda x: 1 << x, xrange(0,16))

def int2bin(it, width = 8):
  result = []
  while(it) : 
    result.insert(0, str(it & 1))
    it >>= 1
  return "0"*(width -len(result)) + "".join(result)

def byte2char(a):
  if a > 0x7F:
    return -256 + a
  return a

def unpack_byte(b):
  return unpack("<B", b)[0]

def unpack_bytes(bytes):
  return unpack("<"+"B"*len(bytes), bytes)

def unpack_word(w):
  return unpack("<H", w)[0]

def unpack_dword(dw):
  return unpack("<L", dw)[0]

def debugi(l = None):
  import sys
  if not l:
    local = sys._getframe(1).f_locals.copy()
  else:
    local = l.copy()
  print "Enter Interactive Debugging:"
  while 1:
    try:
      v = raw_input(">> ")
      if v == "exit":
        raise KeyboardInterrupt
      elif v[0:2] == "p ":
        exec "print " + v[2:] in globals(), local
      else:
        exec v in globals(), local
    except KeyboardInterrupt:
      print "Leave Interactive Debugging"
      return
    except Exception,e:
      print e

def flag_register(register_name , bit):
  l = register_name, MASKS[bit]
  exec("def getter(self): return self.%s & %d" % l)
  exec("def setter(self, v): self.%s |= %d" % l)
  exec("def deleter(self): self.%s &=~%d" % l)
  return property(getter, setter, deleter)

class PartsBase(object):
  def __getattr__(self, name):
    """Add shortcuts for system's properties automatically.
    """
    try:
      value = self.system.__getattribute__(name)
      setattr(self, name, value)
      return value
    except AttributeError, e:
      raise e

