# vim: fileencoding=utf-8
# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
from common import *
import pygame
from pygame.locals import *

class Display(PartsBase):

  # data from http://nesdev.parodius.com/pal.txt
  PALETTE = (
    (117, 117, 117), (39, 27, 143), (0, 0, 171), (71, 0, 159),
    (143, 0, 119), (171, 0, 19), (167, 0, 0), (127, 11, 0),
    (67, 47, 0), (0, 71, 0), (0, 81, 0), (0, 63, 23), (27, 63, 95),
    (0, 0, 0), (0, 0, 0), (0, 0, 0), (188, 188, 188), (0, 115, 239),
    (35, 59, 239), (131, 0, 243), (191, 0, 191), (231, 0, 91),
    (219, 43, 0), (203, 79, 15), (139, 115, 0), (0, 151, 0), (0, 171, 0),
    (0, 147, 59), (0, 131, 139), (0, 0, 0), (0, 0, 0), (0, 0, 0),
    (255, 255, 255), (63, 191, 255), (95, 151, 255), (167, 139, 253),
    (247, 123, 255), (255, 119, 183), (255, 119, 99), (255, 155, 59),
    (243, 191, 63), (131, 211, 19), (79, 223, 75), (88, 248, 152),
    (0, 235, 219), (0, 0, 0), (0, 0, 0), (0, 0, 0), (255, 255, 255),
    (171, 231, 255), (199, 215, 255), (215, 203, 255), (255, 199, 255),
    (255, 199, 219), (255, 191, 179), (255, 219, 171), (255, 231, 163),
    (227, 255, 163), (171, 243, 191), (179, 255, 207), (159, 255, 243),
    (0, 0, 0), (0, 0, 0), (0, 0, 0)
  )

  def __init__(self, system):
    self.system = system
    pygame.init()
    self.is_NTSC = self.nescart.display_type == "NTSC"
    self.offset  = self.is_NTSC and 8 or 0
    self.scr_width = 256
    self.scr_height = self.is_NTSC and 224 or 240
    self.screen = pygame.display.set_mode((self.scr_width, self.scr_height))
    self.display = pygame.display
    self.display.set_caption(u"pynes")
    self.display.flip()
    self.dots_buffer = dict()
    self.set_dots = self.dots_buffer.update

  def flip(self):
    set_at = self.screen.set_at
    dots_buffer = self.dots_buffer
    palette = self.PALETTE
    offset  = self.offset
    for pos in dots_buffer:
      set_at((pos[0], pos[1]-offset), palette[dots_buffer[pos]])
    self.display.update()
