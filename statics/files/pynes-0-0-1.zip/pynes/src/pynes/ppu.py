# vim: fileencoding=utf-8
# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
from common import *
import logging
import sys

class PPU(PartsBase):
  MIRRORING_HORIZONTAL  = 0
  MIRRORING_VERTICAL     = 1
  MIRRORING_FOUR_SCREEN = 2

  DISP_NTSC            = 0
  DISP_PAL             = 1

  LINE_VBLANK_START = 243
  LINE_VBLANK_END   = 262
  LINE_SCREEN_START = 0
  LINE_SCREEN_END   = 240

  SPRITE_SIZE = 8, 16
  BG_PATTERN_ADDR = 0x000, 0x1000
  SPRITE_PATTERN_ADDR = BG_PATTERN_ADDR
  ADDR_INC       = 1 , 32
  NAME_TABLE_ADDR = 0x2000, 0x2400, 0x2800, 0x2c00

  def __init__(self, system):
    self.system = system
    m = lambda n : getattr(self, "write_"+hex(n))
    self.write_methods = map(m, xrange(8))
    #registers
    self.__dict__.update(dict(
      # Control register 1 $2000
      register1            = 0,
      on_vblank_NMI        = 0,
      master_slave         = 1, # Always 1
      sprite_size          = self.SPRITE_SIZE[0],
      bg_pattern_addr      = self.BG_PATTERN_ADDR[0],
      sprite_pattern_addr  = self.SPRITE_PATTERN_ADDR[0],
      addr_inc             = self.ADDR_INC[0],
      name_table_addr      = self.NAME_TABLE_ADDR[0],
      # Control register 2 $2001
      register2            = 0,
      bg_color             = 0,
      sprite_enable        = 0,
      bg_enable            = 0,
      draw_sprite_mask     = 0,
      draw_bg_mask         = 0,
      display_type         = 0,
      # Status register $2002
      status_register      = 0,
      # Others
      sprite_addr          = 0x00, # $2003
      latch                = False,
      #
      vram_write_enable    = system.nescart.num_8k_vrom == 0,
      vrom                 = system.nescart.data_8k_vrom,
      sprite_memory        = [0]*0x100,
      memory               = [0]*0x4000,
      memory_bank          = [i*0x400 for i in xrange(12)],
      palette_memory       = [0]*0x20,
      # loopy (see http://nesdev.parodius.com/loopyppu.zip)
      loopy_v              = 0,
      loopy_x              = 0,
      loopy_t              = 0,

      current_scanline     = 0,
      line_dots            = [0]*264,
      bg_drawn_dots        = [0]*280,
      sprite_drawn_dots    = [0]*280
    ))
    self.set_mirroring(self.system.nescart.mirroring)

  in_vblank  = flag_register("status_register", 7)
  sprite_hit = flag_register("status_register", 6)
  max_sprite = flag_register("status_register", 5)

  def on_frame_start(self):
    offset = not self.draw_sprite_mask and 8 or 0
    self.current_scanline = offset
    if self.sprite_enable and self.bg_enable:
      #frame start (line 0) (if background and sprites are enabled):
      #        v=t
      self.loopy_v = self.loopy_t

  def on_vblank_start(self):
    self.in_vblank = 1

  def on_vblank_end(self):
    #clear a vblank flag and a sprite hit flag
    self.status_register &= 0x3F

  def draw_scanline(self):
    self.line_dots = [64]*264
    self.bg_drawn_dots = [0] * 280
    self.sprite_drawn_dots = [0] * 280
    self.current_scanline += 1
    if self.sprite_enable and self.bg_enable:
      #scanline start (if background and sprites are enabled):
      #      v:0000010000011111=t:0000010000011111
      self.loopy_v &= 0xfbe0
      self.loopy_v |= self.loopy_t & 0x041f
      if self.bg_enable: self.calc_bg()
      if self.sprite_enable : self.calc_sprite()
      if (self.loopy_v & 0x7000) == 0x7000:
        self.loopy_v &= 0x8fff
        if (self.loopy_v & 0x03e0) == 0x03a0:
          self.loopy_v ^= 0x0800
          self.loopy_v &= 0xfc1f
        else:
          if (self.loopy_v & 0x03e0) == 0x03e0:
            self.loopy_v &= 0xfc1f
          else:
            self.loopy_v += 0x0020
      else:
        self.loopy_v += 0x1000
    else:
      if self.bg_enable: self.calc_bg()
      if self.sprite_enable : self.calc_sprite()

    if not self.system.please_draw: return

    dct = self.display.dots_buffer
    palette = self.palette_memory
    current = self.current_scanline
    for i,dot in enumerate(self.line_dots):
      if dot == 64: continue
      dct[(i, current)] = palette[dot]

  def calc_sprite(self):
    sprite_num = 0
    sprite_size = self.sprite_size
    current_line = self.current_scanline
    self.status_register &= 0xdf
    sprite_memory = self.sprite_memory
    read = self.read_0x7
    only_hit_check = not self.system.please_draw

    for i in xrange(64):
      memory_index = i*4
      sprite_y = self.sprite_memory[memory_index] + 1
      line_of_sprite = current_line - sprite_y 
      if line_of_sprite < 0 or line_of_sprite >= sprite_size:
        continue

      sprite_num += 1
      if sprite_num > 8 : self.status_register |= 0x20
      # We just set number of sprites, except sprite0(for sprite hit0)
      if only_hit_check and i:
        continue

      tile_index = sprite_memory[memory_index+1]
      sprite_attrs = sprite_memory[memory_index+2]
      sprite_x = sprite_memory[memory_index+3]
      sprite_v_flip = sprite_attrs & 0x80
      sprite_h_flip = sprite_attrs & 0x40
      sprite_bg_priority = sprite_attrs & 0x20

      x_start = 0
      x_end   = 8
      if (sprite_x + 7) > 255: x_end -= ((sprite_x + 7) - 255)
      y = current_line - sprite_y

      inc_x = 1

      if sprite_h_flip:
        inc_x = -1
        x_start = 7
        x_end   = 7 - x_end

      if sprite_v_flip:
        y = (sprite_size - 1) - y

      if sprite_size == 16:
        tile_addr = tile_index << 4
        if tile_index & 0x01:
          tile_addr += 0x1000
          if y < 8: tile_addr -= 16
        else:
          if y >= 8: tile_addr += 16
        tile_addr += y & 0x07
      else:
        tile_addr = tile_index << 4
        tile_addr += (y & 0x07) + self.sprite_pattern_addr

      pattern_lo = read(tile_addr)
      pattern_hi = read(tile_addr+8)

      for x in xrange(x_start, x_end, inc_x):
        color = 0
        if not self.sprite_drawn_dots[sprite_x]:
          tile_mask = (0x80 >> (x & 0x07))
          if pattern_lo & tile_mask: color |= 0x01
          if pattern_hi & tile_mask: color |= 0x02
          if sprite_attrs & 0x02: color |= 0x08
          if sprite_attrs & 0x01: color |= 0x04

          if color & 0x03:
            if i == 0 and self.bg_drawn_dots[sprite_x]:
              self.status_register |= 0x40
            if self.draw_sprite_mask or (sprite_x >= 8 and sprite_x < 248):
              if sprite_bg_priority:
                self.sprite_drawn_dots[sprite_x] = 1
                if not self.bg_drawn_dots[sprite_x]:
                  self.line_dots[sprite_x] = 16 + color
              else:
                self.line_dots[sprite_x] = 16 + color
                self.sprite_drawn_dots[sprite_x] = 1

        sprite_x += 1

  def calc_bg(self):
    read = self.read_0x7
    x = self.loopy_v & 0x001f
    y = (self.loopy_v & 0x03e0) >> 5
    ym = (y&2)<<1
    name_addr = 0x2000 + (self.loopy_v & 0x0fff)
    attr_addr = 0x23c0 + (self.loopy_v & 0x0c00) + ((self.loopy_v&0x0380)>>4)
    attr_value = read(attr_addr)
    attr_bits = ((attr_value >> ((x&2)+ym)) & 3) << 2
    scroll_x = - self.loopy_x

    for i in xrange(32):
      pattern_addr = self.bg_pattern_addr + (read(name_addr) << 4) + ((self.loopy_v & 0x7000) >> 12)

      pattern_lo = read(pattern_addr)
      pattern_hi = read(pattern_addr+8)

      pattern_mask = 0x80
      while pattern_mask > 0:
        if scroll_x > 0:
          color = attr_bits
          if pattern_lo & pattern_mask : color |= 0x01
          if pattern_hi & pattern_mask : color |= 0x02

          if color & 0x03:
            self.bg_drawn_dots[scroll_x] = 1
            self.line_dots[scroll_x] = color
          else:
            self.bg_drawn_dots[scroll_x] = 0
            self.line_dots[scroll_x] = 0
        scroll_x     += 1
        pattern_mask >>= 1

      x += 1
      name_addr += 1

      if not (x & 0x1):
        if not (x & 0x3):
          if not (x & 0x1f):
            name_addr ^= 0x0400
            attr_addr ^= 0x0400
            name_addr -= 0x0020
            attr_addr -= 0x0008
            x         -= 0x0020
          attr_addr += 1
          attr_value = read(attr_addr)
        attr_bits = ((attr_value >> ((x&2)+ym)) & 3) << 2

    if not self.draw_bg_mask:
      for j in xrange(8):
        self.line_dots[j] = 64
        self.bg_drawn_dots[j] = 0

  def write(self, w_addr, b_data):
    return self.write_methods[w_addr&0x7](b_data)

  def write_0x0(self, b_value):
    self.register1 = b_value
    self.name_table_addr = self.NAME_TABLE_ADDR[b_value & 0x03]
    b_value >>= 2
    self.addr_inc = self.ADDR_INC[b_value & 1]
    b_value >>= 1
    self.sprite_pattern_addr = self.SPRITE_PATTERN_ADDR[b_value & 1]
    b_value >>= 1
    self.bg_pattern_addr = self.BG_PATTERN_ADDR[b_value & 1]
    b_value >>= 1
    self.sprite_size = self.SPRITE_SIZE[b_value & 1]
    self.master_slave = 1
    self.on_vblank_NMI = b_value >> 2
    #2000 write:
    #        t:0000110000000000=d:00000011
    self.loopy_t &= 0xf3ff
    self.loopy_t |= (b_value & 3) << 10
    self.loopy_t &= 0xffff

  def write_0x1(self, b_value):
    self.register2 = b_value
    self.bg_color =  b_value >> 5
    self.sprite_enable = b_value & 0x10
    self.bg_enable     = b_value & 0x08
    self.draw_sprite_mask   = b_value & 0x04
    self.draw_bg_mask       = b_value & 0x02
    self.display_type  = (b_value & 0x01) and 1 or 0

  def write_0x2(self, b_value):
    """Read only."""
    pass

  def write_0x3(self, b_value):
    self.sprite_addr = b_value

  def write_0x4(self, b_value):
    old = self.sprite_addr; self.sprite_addr +=1; self.sprite_addr &= 0xff
    self.sprite_memory[old] = b_value&0xff

  def write_0x5(self, b_value):
    #sys.stdout.write("%d," % b_value)
    if self.latch:
      #2005 second write:
      #        t:0000001111100000=d:11111000
      #        t:0111000000000000=d:00000111
      self.loopy_t &= 0xfc1f
      self.loopy_t |= (b_value & 0xf8) << 2
      self.loopy_t &= 0x8fff
      self.loopy_t = (b_value & 0x07) << 12
      self.loopy_t &= 0xffff
    else:
      #2005 first write:
      #        t:0000000000011111=d:11111000
      #        x=d:00000111
      self.loopy_t &= 0xffe0
      self.loopy_t |= (b_value & 0xf8) >> 3
      self.loopy_t &= 0xffff
      self.loopy_x  = b_value & 0x7
    self.latch = not self.latch

  def write_0x6(self, b_value):
    if self.latch:
      #2006 second write:
      #        t:0000000011111111=d:11111111
      #        v=t
      self.loopy_t &= 0xff00
      self.loopy_t |= b_value
      self.loopy_v = self.loopy_t
    else:
      #2006 first write:
      #        t:0011111100000000=d:00111111
      #        t:1100000000000000=0
      self.loopy_t &= 0xff
      self.loopy_t |= (b_value & 0x3f) << 8
      self.loopy_t &= 0xffff
    self.latch = not self.latch

  def write_0x7(self, b_value):
    w_addr = self.loopy_v & 0x3fff
    self.loopy_v += self.addr_inc
    self.loopy_v &= 0xffff

    if w_addr < 0x2000 and self.vram_write_enable:
      self.memory[self.memory_bank[w_addr>>10]+(w_addr&0x3ff)] = b_value
    elif w_addr < 0x3f00:
      w_addr &= 0xefff
      self.memory[self.memory_bank[w_addr>>10]+(w_addr&0x3ff)] = b_value
    elif not (w_addr & 0xf):
      p = self.palette_memory
      p[0x10] = p[0x14] = p[0x18] = p[0x1c] = \
      p[0x00] = p[0x04] = p[0x08] = p[0x0c] = b_value
      self.palette_memory = p
    elif w_addr & 3:
      self.palette_memory[w_addr & 0x1f] = b_value

  def read(self, w_addr):
    v = w_addr&0x07
    if v == 0x02:
      ret = self.status_register
      del self.in_vblank
      self.latch = False
      if self.current_scanline >= self.LINE_VBLANK_START and \
         not self.on_vblank_NMI:
        self.sprite_pattern_addr = self.SPRITE_PATTERN_ADDR[0]
      return ret
    elif v == 0x04:
      old = self.sprite_addr; self.sprite_addr +=1; self.sprite_addr &= 0xff
      return self.sprite_memory[old]
    elif v == 0x07:
      w_addr = self.loopy_v & 0x3fff
      self.loopy_v += self.addr_inc
      self.loopy_v &= 0xffff
    else:
      pass
    return self.read_0x7(w_addr)

  def read_0x7(self, w_addr):
    if w_addr < 0x2000:
      #return self.read_pattern(w_addr)
      mem = self.vram_write_enable and self.memory or self.vrom
      w_addr = self.memory_bank[(w_addr&0x1fff)>>10]+(w_addr&0x3ff)
      return mem[w_addr]
    if w_addr >= 0x3000:
      if w_addr > 0x3f00:
        return self.palette_memory[w_addr & 0x1f]
      w_addr &= 0xefff
    #return self.read_vram(w_addr)
    return self.memory[self.memory_bank[w_addr>>10]+(w_addr&0x3ff)]

  def set_memory_bank(self, index, offset):
    self.memory_bank[index] = offset

  def set_mirroring(self, type):
    lst = 0, 1, 2, 3
    if type == self.MIRRORING_VERTICAL:
      lst = 0, 1, 0, 1
    elif type == self.MIRRORING_HORIZONTAL:
      lst = 0, 0, 1, 1
    for i, v in enumerate(xrange(8, 12, 1)):
      self.memory_bank[v] = 0x2000 + (lst[i]*0x400)
