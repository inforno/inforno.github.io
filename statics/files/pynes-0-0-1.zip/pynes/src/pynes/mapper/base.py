#vim: fileencoding=utf8
# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
from pynes.common import *

class Mapper(object):
  def __init__(self, system):
    self.nescart = system.nescart
    self.system = system
    self.__dict__.update(dict(
      sram_bank = None,
      rom_bank = [0,0,0,0]
    ))
    self.set_sram_bank()
    self.set_rom_bank()
    self.set_ppu_bank()

  def set_sram_bank(self):
    self.sram_bank = self.nescart.sram

  def set_rom_bank(self):
    pat = 0,0,0,0
    if self.nescart.num_16k_prgrom > 1:
      pat = 0, 1, 2, 3
    elif self.nescart.num_16k_prgrom > 0:
      pat = 0, 1, 0, 1
    self.rom_bank = pat

  def set_ppu_bank(self):
    for i in xrange(8):
      self.system.ppu.set_memory_bank(i, i*0x400)

  def read_rom_bank(self, no, w_addr):
    return self.nescart.data_16k_prgrom[(self.rom_bank[no]*0x2000)+w_addr]

  def copy_rom_bank(self, no, start, length):
    start = (self.rom_bank[no]*0x2000)+start
    return self.nescart.data_16k_prgrom[start:start+length]

  def write_mapper(self, w_addr, b_data):
    pass

  def write_sram(self, w_addr, b_data):
    pass

  def write_apu(self, w_addr, b_data):
    pass

  def read_apu(self, w_addr):
    return w_addr >> 8 

  def vsync_callback(self):
    pass

  def hsync_callback(self, line):
    return 0

  def ppu_callback(self):
    pass

  def render_screen_callback(self, b_mode):
    pass
