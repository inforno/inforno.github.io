# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
