# vim: fileencoding=utf-8
# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
import base
from pynes.common import *

class Mapper(base.Mapper):
  def __init__(self, system):
    base.Mapper.__init__(self, system)

    #TODO PPU

