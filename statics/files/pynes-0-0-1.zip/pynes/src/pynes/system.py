# vim: fileencoding=utf-8
# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
import sys
import os
import time
from common import *
import threading
import pynes
from pynes.cpu import *
from pynes.cartridge import *
from pynes.ppu    import *
from pynes.display import *
from pynes.pad import *

class System(threading.Thread):
  STEP_PER_SCANLINE = 112
  STEP_PER_FRAME    = 29828
  
  def __init__(self, rom_fname, skip_limit = 10):
    threading.Thread.__init__(self)
    self.nescart = Cartridge(rom_fname)
    self.ppu    = PPU(self)
    self.memory = Memory(self)
    self.mapper = self.create_mapper()
    self.cpu    = CPU(self)
    self.display= Display(self)
    self.pad     = Pad(self)

    self.skip_limit = skip_limit
    self.halt   = False
    self.please_draw = False
    self.frameIRQ = False

    self.debug = False

  def create_mapper(self):
    try :
      nescart = self.nescart
      name = "no%d"%nescart.mapper_no
      mapper_mod = __import__("pynes.mapper.%s"%name)
      return getattr(getattr(mapper_mod, "mapper"), name).Mapper(self)
    except ImportError, e:
      raise StandardError("Not supported mapper : %d" % nescart.mapper_no)

  def stop(self):
    self.halt = True

  def run(self):
    now = time.time
    sleep = time.sleep
    time_per_frame = 1/60
    skip_limit = self.skip_limit - 1
    cycle = self.cycle

    next = now()+time_per_frame
    skip = 0
    while 1:
      if self.halt:
        self.halt = False
        return
      cycle()

      if self.please_draw:
        self.display.flip()
        self.please_draw = False
      if next > now():
        self.please_draw = True
        skip = 0
        if next > now(): sleep(next-now())
      else:
        skip += 1
        if skip > skip_limit:
          self.please_draw = True
          skip = 0
          next = now()
      next += time_per_frame

  def cycle(self):
    ppu = self.ppu
    cpu = self.cpu
    mapper = self.mapper
    step_execute = cpu.step_execute
    raise_interrupts = cpu.raise_interrupts
    draw_scanline = ppu.draw_scanline

    ppu.on_frame_start()
    for i in xrange(ppu.LINE_SCREEN_END):
      step_execute(self.STEP_PER_SCANLINE)
      if mapper.hsync_callback(i):
        raise_interrupts(INT_IRQ)
      draw_scanline()

    if self.frameIRQ: raise_interrupts(INT_IRQ)

    for i in xrange(ppu.LINE_SCREEN_END, ppu.LINE_VBLANK_END):
      if i == 261:
        ppu.on_vblank_end()
      if i == 240:
        ppu.on_vblank_start()
        mapper.vsync_callback()
        step_execute(1)
        if ppu.on_vblank_NMI:
          raise_interrupts(INT_NMI)
        step_execute(self.STEP_PER_SCANLINE - 1)
        if mapper.hsync_callback(i):
          raise_interrupts(INT_IRQ)
      else:
        step_execute(self.STEP_PER_SCANLINE)
        if mapper.hsync_callback(i):
            raise_interrupts(INT_IRQ)



