# vim: fileencoding=utf-8
# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
import os
import sys
from common import *
from cartridge import *
import threading
import logging
import re

#{{{ PreFetchCue
class PreFetchCue(threading.Thread):
  def __init__(self, cpu, memory):
    threading.Thread.__init__(self)
    self.cpu = cpu
    self.memory = memory
    self.cue = dict()

  def run(self):
    import time
    sleep = time.sleep
    cpu = self.cpu
    wait = 0.0000001
    read = self.memory.read
    cue = self.cue
    it  = range(4)
    while 1:
      sleep(wait)
      pc = cpu.PC
      for i in it:
        j = pc + i
        cue[j] = read(j)
    return
#}}}

#{{{ Memory
class Memory(PartsBase):
  def __init__(self, system):
    self.system = system
    self.ram = [0]*0x2000

  #######################################
  #{{{ Reading methods
  #######################################
  def read(self, w_addr):
    v = w_addr & 0xe000
    m = self.mapper
    # ram
    if v == 0x0000: return self.ram[w_addr & 0x7ff]
    # ppu
    elif v == 0x2000: return self.ppu.read(w_addr)
    # sound
    elif v == 0x4000: 
      v2 = w_addr & 0x1f
      # pad : player1
      if v2 == 0x16:
        return self.pad.read_pad1()
      # pad : player2
      if v2 == 0x17:
        return self.pad.read_pad2()
      #TODO delegate to the mapper
    # sram
    elif v == 0x6000:
      if self.nescart.has_sram:
        return self.nescart.sram[w_addr & 0x1fff]
      else:
        return m.sram_bank[w_addr & 0x1fff]
    # rom
    elif v == 0x8000: return m.read_rom_bank(0, w_addr & 0x1fff)
    elif v == 0xa000: return m.read_rom_bank(1, w_addr & 0x1fff)
    elif v == 0xc000: return m.read_rom_bank(2, w_addr & 0x1fff)
    elif v == 0xe000: return m.read_rom_bank(3, w_addr & 0x1fff)

    return w_addr >> 8

  def readw(self, w_addr):
    read = self.read
    return read(w_addr) | (read((w_addr+1)&0xffff) << 8)

  def readw_bug(self, w_addr):
    if 0xff == w_addr & 0xff:
      return self.read(w_addr) | (self.read(w_addr - 0xff) << 8)
    return self.readw(w_addr)

  #Zero page
  def zero_page_read(self, b_addr):
    return self.ram[b_addr]

  def zero_page_readw(self, b_addr):
    zpread = self.zero_page_read
    return zpread(b_addr) | (zpread((b_addr + 1)&0xff) << 8)

  #}}}
  #######################################
  #{{{ Writing methods
  #######################################
  def write(self, w_addr, b_data):
    v = w_addr & 0xe000
    b_data &= 0xff
    # ram
    if v == 0x0000 : self.ram[w_addr & 0x7ff] = b_data
    # ppu
    elif v == 0x2000: self.ppu.write(w_addr, b_data)
    # sound
    elif v == 0x4000:
      v2 = w_addr & 0x1f
      # sprite DMA
      if v2 == 0x14:
        self.sprite_DMA(b_data)
      # reset pad
      elif v2 == 0x16:
        self.pad.write(b_data)
      # frame IRQ
      elif v2 == 0x17:
        self.frameIRQ = not (b_data & 0xc0)
    # sram
    elif v == 0x6000:
      self.nescart.sram[w_addr & 0x1fff] = b_data
      if not self.nescart.has_sram:
        self.mapper.write_sram(w_addr, b_data)
    # mapper
    elif v == 0x8000 or v == 0xa000 or v == 0xc000 or v == 0xe000:
      self.mapper.write_mapper(w_addr, b_data)
    else:
      pass

  def writew(self, w_addr, w_data):
    write = self.write
    write(w_addr, w_data & 0xff)
    write(w_addr+1, w_data >> 8)

  def sprite_DMA(self, b_data):
    v = b_data >> 5
    if   v == 0x0:
      start = (b_data << 8) & 0x7ff
      self.ppu.sprite_memory = self.ram[start:start+0x100]
      return
    else:
      start = (b_data << 8) & 0x1fff
    if v   == 0x3:
      self.ppu.sprite_memory = self.nescart.sram[start:end]
    elif v == 0x4:
      self.ppu.sprite_memory = self.mapper.copy_rom_bank(0, start, 0x100)
    elif v == 0x5:
      self.ppu.sprite_memory = self.mapper.copy_rom_bank(1, start, 0x100)
    elif v == 0x6:
      self.ppu.sprite_memory = self.mapper.copy_rom_bank(2, start, 0x100)
    elif v == 0x7:
      self.ppu.sprite_memory = self.mapper.copy_rom_bank(3, start, 0x100)

  #}}}
#}}}

#{{{ Interrupts
INT_NONE  = 0x01 # No interrupt required
INT_IRQ   = 0x02 # Standard IRQ interrupt
INT_NMI   = 0x04 # Non-maskable interrupt
INT_RESET = 0x08 # Exit the emulation
INT_VECTOR_IRQ = 0xfffe
INT_VECTOR_NMI = 0xfffa
INT_VECTOR_RESET = 0xfffc
#}}}

#{{{ Flags
FLAG_LIST = 'C', 'Z', 'I', 'D', 'B', 'R', 'V', 'N'
FLAG_C = MASKS[0] # 1: Carry occured
FLAG_Z = MASKS[1] # 1: Reault is zero
FLAG_I = MASKS[2] # 1: Interrupts disabled
FLAG_D = MASKS[3] # 1: Decimal mode
FLAG_B = MASKS[4] # Break [0 on stk after int]
FLAG_R = MASKS[5] # Always 1
FLAG_V = MASKS[6] # 1: Overflow occured
FLAG_N = MASKS[7] # 1: Result is negative
#}}}

#{{{ CYCLES
CYCLES = (
  7,6,2,8,3,3,5,5,3,2,2,2,4,4,6,6,
  2,5,2,8,4,4,6,6,2,4,2,7,5,5,7,7,
  6,6,2,8,3,3,5,5,4,2,2,2,4,4,6,6,
  2,5,2,8,4,4,6,6,2,4,2,7,5,5,7,7,
  6,6,2,8,3,3,5,5,3,2,2,2,3,4,6,6,
  2,5,2,8,4,4,6,6,2,4,2,7,5,5,7,7,
  6,6,2,8,3,3,5,5,4,2,2,2,5,4,6,6,
  2,5,2,8,4,4,6,6,2,4,2,7,5,5,7,7,
  2,6,2,6,3,3,3,3,2,2,2,2,4,4,4,4,
  2,6,2,6,4,4,4,4,2,5,2,5,5,5,5,5,
  2,6,2,6,3,3,3,3,2,2,2,2,4,4,4,4,
  2,5,2,5,4,4,4,4,2,4,2,5,4,4,4,4,
  2,6,2,8,3,3,5,5,2,2,2,2,4,4,6,6,
  2,5,2,8,4,4,6,6,2,4,2,7,5,5,7,7,
  2,6,2,8,3,3,5,5,2,2,2,2,4,4,6,6,
  2,5,2,8,4,4,6,6,2,4,2,7,5,5,7,7
)
#}}}

#{{{ ZN_TABLE
ZN_TABLE = (
  FLAG_Z,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
  FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,FLAG_N,
)
#}}}

#{{{ CPU
class CPU(PartsBase):
  STACK_BASE = 0x100

  def __init__(self, system):
    self.system = system
    self.mread = self.memory.read
    self.mreadw = self.memory.readw
    self.mzpread = self.memory.zero_page_read
    self.mzpreadw = self.memory.zero_page_readw
    self.reset()
    self.opecode_methods = map(self._create_method_caches, xrange(0x100))

    #prefetch cue
    self.prefetch_cue = PreFetchCue(self, self.memory)
    self.prefetch_cue.setDaemon(True)
    self.prefetch_cue.start()
    self.prefetch_cue_get = self.prefetch_cue.cue.get

  def reset(self):
    self.__dict__.update(dict(
    A = 0x00,
    X = 0x00,
    Y = 0x00,
    SP = 0xff,
    P = FLAG_Z | FLAG_R | FLAG_I,
    PC = self.mreadw(INT_VECTOR_RESET),
    requested_interrupt = INT_NONE,
    passed_clocks = 0
    ))

  def __str__(self):
    result = ["Registers:"]
    result.extend(map(lambda x: x+" : "+"$%02X"%getattr(self, x),[
      "A", "X", "Y", "SP"
    ]))
    result.append("PC : $%04X"%self.PC)
    result.append("\nFlags:")
    result.append(" | ".join(FLAG_LIST))
    result.append(" | ".join(reversed(int2bin(self.P))))
    return "\n".join(result)

  def _int_common(self, int_type, vector):
    self.reset_interrupts(int_type)
    self.passed_clocks += 7
    self.pushw(self.PC)
    self.push(self.P & ~FLAG_B)
    del self.D_flag
    self.I_flag = 1
    self.PC = self.mreadw(vector)

  def step_execute(self, clocks):
    if self.is_NMI_requested():
      self._int_common(INT_NMI, INT_VECTOR_NMI)
    elif self.is_IRQ_requested() and not self.I_flag:
      self._int_common(INT_IRQ, INT_VECTOR_IRQ)

    read = self.memory.read
    cue_get      = self.prefetch_cue_get
    methods = self.opecode_methods
    while (self.passed_clocks < clocks):
      old = self.PC; self.PC += 1; self.PC &= 0xffff
      opecode = cue_get(old) or read(old)
      method  = methods[opecode]
      #if self.system.debug: print self.disasm(method)
      count = method()
      count = count is not None and count or CYCLES[opecode]
      self.passed_clocks += count
    self.passed_clocks -= clocks

  def disasm(self, method):
    op = str(method.__doc__ or method.__name__)
    if method.operand_length == 2:
      op = op.replace("$ssss", "$%04X"% self.mreadw(self.PC))
    elif method.operand_length == 1:
      op = op.replace("$ss", "$%02X"% self.mread(self.PC))
    return "[PC:0x%04X][opecode:%04X] %s" % (self.PC-1, method.opecode, op)

  #{{{ Opecode
  def _create_method_caches(self, opecode):
    method_name = self._create_method_caches.lst.get(opecode)
    if method_name:  
      method = self.__getattribute__(method_name)
    else:
      try: 
        method = self.__getattribute__("ope_"+hex(opecode))
      except Exception, e:
        method = self.ope_default
    method.__dict__["opecode"] = opecode
    op = str(method.__doc__ or method.__name__)
    if   op.count("$ssss") : method.__dict__["operand_length"] = 2
    elif op.count("$ss")   : method.__dict__["operand_length"] = 1
    else                   : method.__dict__["operand_length"] = 0

    return method
  _create_method_caches.lst ={
    0x10:"BPL", 0x30:"BMI", 0xd0:"BNE", 0xf0:"BEQ", 0x90:"BCC", 0xb0:"BCS",
    0x50:"BVC", 0x70:"BVS", 0x60:"RTS", 0x20:"JSR", 0x00:"BRK", 0x28:"PLP",
    0x08:"PHP", 0x18:"CLC", 0xb8:"CLV", 0xd8:"CLD", 0x38:"SEC", 0xf8:"SED",
    0x78:"SEI", 0x48:"PHA", 0x68:"PLA", 0x98:"TYA", 0xA8:"TAY", 0xC8:"INY",
    0x88:"DEY", 0x8A:"TXA", 0xAA:"TAX", 0xE8:"INX", 0xCA:"DEX", 0xEA:"NOP",
    0x9A:"TXS", 0xBA:"TSX", 0x1a:"NOP", 0x3a:"NOP", 0x5a:"NOP", 0x7a:"NOP", 
    0xda:"NOP", 0xfa:"NOP", 0x80:"DOP", 0x82:"DOP", 0x89:"DOP", 0xc2:"DOP", 
    0xe2:"DOP", 0x04:"DOP", 0x44:"DOP", 0x64:"DOP", 0x14:"DOP", 0x34:"DOP", 
    0x54:"DOP", 0x74:"DOP", 0xd4:"DOP", 0xf4:"DOP", 0x0c:"TOP", 0x1c:"TOP", 
    0x3c:"TOP", 0x5c:"TOP", 0x7c:"TOP", 0xdc:"TOP", 0xfc:"TOP" ,0x40:"RTI"
  }
  def ope_default(self):
    raise StandardError("unknown opecode:0x%04X" % self.mread(self.PC-1))
    return 2

  def ope_0x4c(self):
    """JMP $ssss ABS"""
    self.JMP(self.absolute_addressing())
  def ope_0x6c(self):
    """JMP ($ssss)"""
    self.JMP(self.memory.readw_bug(self.absolute_addressing()))
  def ope_0x58(self):
    """CLI"""
    old = self.P
    del self.I_flag
    if (old & FLAG_I) and self.is_IRQ_requested():
      self._int_common(INT_IRQ, INT_VECTOR_IRQ)
  def ope_0x24(self):
    """BIT $ss ZP"""
    self.BIT(self.read_zero_page())
  def ope_0x2c(self):
    """BIT $ssss ABS"""
    self.BIT(self.read_absolute())

  def ope_0x5(self):
    """ORA $ss ZP"""
    self.ORA(self.read_zero_page())
  def ope_0x6(self):
    """ASL $ss ZP"""
    self.rs_by_addr("ASL", self.zero_page_addressing())
  def ope_0x25(self):
    """AND $ss ZP"""
    self.AND(self.read_zero_page())
  def ope_0x26(self):
    """ROL $ss ZP"""
    self.rs_by_addr("ROL", self.zero_page_addressing())
  def ope_0x45(self):
    """EOR $ss ZP"""
    self.EOR(self.read_zero_page())
  def ope_0x46(self):
    """LSR $ss ZP"""
    self.rs_by_addr("LSR", self.zero_page_addressing())
  def ope_0x65(self):
    """ADC $ss ZP"""
    self.ADC(self.read_zero_page())
  def ope_0x66(self):
    """ROR $ss ZP"""
    self.rs_by_addr("ROR", self.zero_page_addressing())
  def ope_0x84(self):
    """STY $ss ZP"""
    self.STY(self.zero_page_addressing())
  def ope_0x85(self):
    """STA $ss ZP"""
    self.STA(self.zero_page_addressing())
  def ope_0x86(self):
    """STX $ss ZP"""
    self.STX(self.zero_page_addressing())
  def ope_0xa4(self):
    """LDY $ss ZP"""
    self.LDY(self.read_zero_page())
  def ope_0xa5(self):
    """LDA $ss ZP"""
    self.LDA(self.read_zero_page())
  def ope_0xa6(self):
    """LDX $ss ZP"""
    self.LDX(self.read_zero_page())
  def ope_0xc4(self):
    """CPY $ss ZP"""
    self.CPY(self.read_zero_page())
  def ope_0xc5(self):
    """CMP $ss ZP"""
    self.CMP(self.read_zero_page())
  def ope_0xc6(self):
    """DEC $ss ZP"""
    self.DEC(self.zero_page_addressing())
  def ope_0xe4(self):
    """CPX $ss ZP"""
    self.CPX(self.read_zero_page())
  def ope_0xe5(self):
    """SBC $ss ZP"""
    self.SBC(self.read_zero_page())
  def ope_0xe6(self):
    """INC $ss ZP"""
    self.INC(self.zero_page_addressing())

  def ope_0xd(self):
    """ORA $ssss ABS"""
    self.ORA(self.read_absolute())
  def ope_0xe(self):
    """ASL $ssss ABS"""
    self.rs_by_addr("ASL", self.absolute_addressing())
  def ope_0x2d(self):
    """AND $ssss ABS"""
    self.AND(self.read_absolute())
  def ope_0x2e(self):
    """ROL $ssss ABS"""
    self.rs_by_addr("ROL", self.absolute_addressing())
  def ope_0x4d(self):
    """EOR $ssss ABS"""
    self.EOR(self.read_absolute())
  def ope_0x4e(self):
    """LSR $ssss ABS"""
    self.rs_by_addr("LSR", self.absolute_addressing())
  def ope_0x6d(self):
    """ADC $ssss ABS"""
    self.ADC(self.read_absolute())
  def ope_0x6e(self):
    """ROR $ssss ABS"""
    self.rs_by_addr("ROR", self.absolute_addressing())
  def ope_0x8c(self):
    """STY $ssss ABS"""
    self.STY(self.absolute_addressing())
  def ope_0x8d(self):
    """STA $ssss ABS"""
    self.STA(self.absolute_addressing())
  def ope_0x8e(self):
    """STX $ssss ABS"""
    self.STX(self.absolute_addressing())
  def ope_0xac(self):
    """LDY $ssss ABS"""
    self.LDY(self.read_absolute())
  def ope_0xad(self):
    """LDA $ssss ABS"""
    # inlining
    old = self.PC; self.PC = self.PC + 2; self.PC &= 0xffff
    cue_get = self.prefetch_cue_get
    a = cue_get(old)
    b = cue_get((old+1)&0xffff)
    if a != None and b != None:
      w_addr = a | (b << 8)
    else:
      w_addr = self.mreadw(old)
    b_value = self.mread(w_addr)
    self.A = b_value & 0xff
    self.flag_test(self.A)
    #self.LDA(self.read_absolute())
  def ope_0xae(self):
    """LDX $ssss ABS"""
    self.LDX(self.read_absolute())
  def ope_0xcc(self):
    """CPY $ssss ABS"""
    self.CPY(self.read_absolute())
  def ope_0xcd(self):
    """CMP $ssss ABS"""
    self.CMP(self.read_absolute())
  def ope_0xce(self):
    """DEC $ssss ABS"""
    self.DEC(self.absolute_addressing())
  def ope_0xec(self):
    """CPX $ssss ABS"""
    self.CPX(self.read_absolute())
  def ope_0xed(self):
    """SBC $ssss ABS"""
    self.SBC(self.read_absolute())
  def ope_0xee(self):
    """INC $ssss ABS"""
    self.INC(self.absolute_addressing())

  def ope_0x9(self):
    """ORA #$ss IMM"""
    self.ORA(self.read_immediate())
  def ope_0x29(self):
    """AND #$ss IMM"""
    self.AND(self.read_immediate())
  def ope_0x49(self):
    """EOR #$ss IMM"""
    self.EOR(self.read_immediate())
  def ope_0x69(self):
    """ADC #$ss IMM"""
    self.ADC(self.read_immediate())
  def ope_0xa0(self):
    """LDY #$ss IMM"""
    self.LDY(self.read_immediate())
  def ope_0xa2(self):
    """LDX #$ss IMM"""
    self.LDX(self.read_immediate())
  def ope_0xa9(self):
    """LDA #$ss IMM"""
    self.LDA(self.read_immediate())
  def ope_0xc0(self):
    """CPY #$ss IMM"""
    self.CPY(self.read_immediate())
  def ope_0xc9(self):
    """CMP #$ss IMM"""
    self.CMP(self.read_immediate())
  def ope_0xe0(self):
    """CPX #$ss IMM"""
    self.CPX(self.read_immediate())
  def ope_0xe9(self):
    """SBC #$ss IMM"""
    self.SBC(self.read_immediate())

  def ope_0x15(self):
    """ORA $ss ZP,x"""
    self.ORA(self.read_zero_page_x())
  def ope_0x16(self):
    """ASL $ss ZP,x"""
    self.rs_by_addr("ASL", self.indexed_zero_page_addressing_x())
  def ope_0x35(self):
    """AND $ss ZP,x"""
    self.AND(self.read_zero_page_x())
  def ope_0x36(self):
    """ROL $ss ZP,x"""
    self.rs_by_addr("ROL", self.indexed_zero_page_addressing_x())
  def ope_0x55(self):
    """EOR $ss ZP,x"""
    self.EOR(self.read_zero_page_x())
  def ope_0x56(self):
    """LSR $ss ZP,x"""
    self.rs_by_addr("LSR", self.indexed_zero_page_addressing_x())
  def ope_0x75(self):
    """ADC $ss ZP,x"""
    self.ADC(self.read_zero_page_x())
  def ope_0x76(self):
    """ROR $ss ZP,x"""
    self.rs_by_addr("ROR", self.indexed_zero_page_addressing_x())
  def ope_0x94(self):
    """STY $ss ZP,x"""
    self.STY(self.indexed_zero_page_addressing_x())
  def ope_0x95(self):
    """STA $ss ZP,x"""
    self.STA(self.indexed_zero_page_addressing_x())
  def ope_0x96(self):
    """STX $ss ZP,x"""
    self.STX(self.indexed_zero_page_addressing_x())
  def ope_0xb4(self):
    """LDY $ss ZP,x"""
    self.LDY(self.read_zero_page_x())
  def ope_0xb5(self):
    """LDA $ss ZP,x"""
    self.LDA(self.read_zero_page_x())
  def ope_0xb6(self):
    """LDX $ss ZP,x"""
    self.LDX(self.read_zero_page_x())
  def ope_0xd5(self):
    """CMP $ss ZP,x"""
    self.CMP(self.read_zero_page_x())
  def ope_0xd6(self):
    """DEC $ss ZP,x"""
    self.DEC(self.indexed_zero_page_addressing_x())
  def ope_0xf5(self):
    """SBC $ss ZP,x"""
    self.SBC(self.read_zero_page_x())
  def ope_0xf6(self):
    """INC $ss ZP,x"""
    self.INC(self.indexed_zero_page_addressing_x())


  def ope_0x1d(self):
    """ORA $ssss,x ABS,x"""
    self.ORA(self.read_absolute_x())
  def ope_0x1e(self):
    """ASL $ssss,x ABS,x"""
    self.rs_by_addr("ASL", self.indexed_absolute_addressing_x())
  def ope_0x3d(self):
    """AND $ssss,x ABS,x"""
    self.AND(self.read_absolute_x())
  def ope_0x3e(self):
    """ROL $ssss,x ABS,x"""
    self.rs_by_addr("ROL", self.indexed_absolute_addressing_x())
  def ope_0x5d(self):
    """EOR $ssss,x ABS,x"""
    self.EOR(self.read_absolute_x())
  def ope_0x5e(self):
    """LSR $ssss,x ABS,x"""
    self.rs_by_addr("LSR", self.indexed_absolute_addressing_x())
  def ope_0x7d(self):
    """ADC $ssss,x ABS,x"""
    self.ADC(self.read_absolute_x())
  def ope_0x7e(self):
    """ROR $ssss,x ABS,x"""
    self.rs_by_addr("ROR", self.indexed_absolute_addressing_x())
  def ope_0x9d(self):
    """STA $ssss,x ABS,x"""
    self.STA(self.indexed_absolute_addressing_x())
  def ope_0xbc(self):
    """LDY $ssss,x ABS,x"""
    self.LDY(self.read_absolute_x())
  def ope_0xbd(self):
    """LDA $ssss,x ABS,x"""
    self.LDA(self.read_absolute_x())
  def ope_0xdd(self):
    """CMP $ssss,x ABS,x"""
    self.CMP(self.read_absolute_x())
  def ope_0xde(self):
    """DEC $ssss,x ABS,x"""
    self.DEC(self.indexed_absolute_addressing_x())
  def ope_0xfd(self):
    """SBC $ssss,x ABS,x"""
    self.SBC(self.read_absolute_x())
  def ope_0xfe(self):
    """INC $ssss,x ABS,x"""
    self.INC(self.indexed_absolute_addressing_x())

  def ope_0x19(self):
    """ORA $ssss,y ABS,y"""
    self.ORA(self.read_absolute_y())
  def ope_0x39(self):
    """AND $ssss,y ABS,y"""
    self.AND(self.read_absolute_y())
  def ope_0x59(self):
    """EOR $ssss,y ABS,y"""
    self.EOR(self.read_absolute_y())
  def ope_0x79(self):
    """ADC $ssss,y ABS,y"""
    self.ADC(self.read_absolute_y())
  def ope_0x99(self):
    """STA $ssss,y ABS,y"""
    self.STA(self.indexed_absolute_addressing_y())
  def ope_0xb9(self):
    """LDA $ssss,y ABS,y"""
    self.LDA(self.read_absolute_y())
  def ope_0xbe(self):
    """LDX $ssss,y ABS,y"""
    self.LDX(self.read_absolute_y())
  def ope_0xd9(self):
    """CMP $ssss,y ABS,y"""
    self.CMP(self.read_absolute_y())
  def ope_0xf9(self):
    """SBC $ssss,y ABS,y"""
    self.SBC(self.read_absolute_y())


  def ope_0x1(self):
    """ORA ($ss,x) INDEXINDIR"""
    self.ORA(self.read_indirect_x())
  def ope_0x21(self):
    """AND ($ss,x) INDEXINDIR"""
    self.AND(self.read_indirect_x())
  def ope_0x41(self):
    """EOR ($ss,x) INDEXINDIR"""
    self.EOR(self.read_indirect_x())
  def ope_0x61(self):
    """ADC ($ss,x) INDEXINDIR"""
    self.ADC(self.read_indirect_x())
  def ope_0x81(self):
    """STA ($ss,x) INDEXINDIR"""
    self.STA(self.indexed_indirect_addressing())
  def ope_0xa1(self):
    """LDA ($ss,x) INDEXINDIR"""
    self.LDA(self.read_indirect_x())
  def ope_0xc1(self):
    """CMP ($ss,x) INDEXINDIR"""
    self.CMP(self.read_indirect_x())
  def ope_0xe1(self):
    """SBC ($ss,x) INDEXINDIR"""
    self.SBC(self.read_indirect_x())

  def ope_0x11(self):
    """ORA ($ss),y INDEXINDIR"""
    self.ORA(self.read_indirect_y())
  def ope_0x31(self):
    """AND ($ss),y INDEXINDIR"""
    self.AND(self.read_indirect_y())
  def ope_0x51(self):
    """EOR ($ss),y INDEXINDIR"""
    self.EOR(self.read_indirect_y())
  def ope_0x71(self):
    """ADC ($ss),y INDEXINDIR"""
    self.ADC(self.read_indirect_y())
  def ope_0x91(self):
    """STA ($ss),y INDEXINDIR"""
    self.STA(self.indirect_indexed_addressing())
  def ope_0xb1(self):
    """LDA ($ss),y INDEXINDIR"""
    self.LDA(self.read_indirect_y())
  def ope_0xd1(self):
    """CMP ($ss),y INDEXINDIR"""
    self.CMP(self.read_indirect_y())
  def ope_0xf1(self):
    """SBC ($ss),y INDEXINDIR"""
    self.SBC(self.read_indirect_y())

  def ope_0xa(self):
    """ASL a ACC"""
    self.A = self.ASL(self.A) & 0xff
  def ope_0x2a(self):
    """ROL a ACC"""
    self.A = self.ROL(self.A) & 0xff
  def ope_0x4a(self):
    """LSR a ACC"""
    self.A = self.LSR(self.A) & 0xff
  def ope_0x6a(self):
    """ROR a ACC"""
    self.A = self.ROR(self.A) & 0xff
  #}}}

  #{{{ Opes
  def NOP(self):
    return 2
  def DOP(self):
    self.PC = self.PC + 1; self.PC &= 0xffff
  def TOP(self):
    self.PC += 2; self.PC &= 0xffff
  ################################################
  #{{{ Interrupts
  #################################################
  def raise_interrupts(self, ints):
    self.requested_interrupt |= ints

  def reset_interrupts(self, ints):
    self.requested_interrupt &= ~ints

  def is_NMI_requested(self):
    return self.requested_interrupt & INT_NMI

  def is_IRQ_requested(self):
    return self.requested_interrupt & INT_IRQ

  def BRK(self):
    self.PC = self.PC + 1; self.PC &= 0xffff
    self.pushw(self.PC)
    self.B_flag = 1
    self.push(self.P)
    self.I_flag = 1
    del self.D_flag
    self.PC = self.mreadw(INT_VECTOR_IRQ)

  def RTI(self):
    self.P = self.pop()
    self.R_flag = 1
    self.PC = self.popw()

  #}}}
  #################################################
  #{{{ Addressings
  #################################################

  def zero_page_addressing(self):
    old = self.PC; self.PC = self.PC + 1; self.PC &= 0xffff
    return self.prefetch_cue_get(old) or self.mread(old)

  def indexed_zero_page_addressing_x(self):
    old = self.PC; self.PC = self.PC + 1; self.PC &= 0xffff
    return ((self.prefetch_cue_get(old) or self.mread(old)) + self.X) & 0xff

  def indexed_zero_page_addressing_y(self):
    old = self.PC; self.PC = self.PC + 1; self.PC &= 0xffff
    return ((self.prefetch_cue_get(old) or self.mread(old)) + self.Y) & 0xff

  def absolute_addressing(self):
    old = self.PC; self.PC = self.PC + 2; self.PC &= 0xffff
    cue_get = self.prefetch_cue_get
    a = cue_get(old)
    b = cue_get((old+1)&0xffff)
    if a != None and b != None:
      return a | (b << 8)
    return self.mreadw(old)

  def indexed_absolute_addressing_x(self):
    return (self.absolute_addressing() + self.X) & 0xffff

  def indexed_absolute_addressing_y(self):
    return (self.absolute_addressing() + self.Y) & 0xffff

  def indexed_indirect_addressing(self):
    old = self.PC; self.PC = self.PC + 1; self.PC &= 0xffff
    return self.mzpreadw(((self.prefetch_cue_get(old) or self.mread(old)) + self.X) & 0xff )

  def indirect_indexed_addressing(self):
    old = self.PC; self.PC = self.PC + 1; self.PC &= 0xffff
    return (self.mzpreadw((self.prefetch_cue_get(old) or self.mread(old))) + self.Y) & 0xffff

  def absolute_indirect_addressing(self):
    return self.mreadw(self.absolute_addressing())

  #}}}
  ####################################################
  #{{{ Reading methods
  ####################################################
  
  def read_zero_page(self):
    return self.mzpread(self.zero_page_addressing())

  def read_zero_page_x(self):
    return self.mzpread(self.indexed_zero_page_addressing_x())

  def read_zero_page_y(self):
    return self.mzpread(self.indexed_zero_page_addressing_y())

  def read_absolute(self):
    return self.mread(self.absolute_addressing())

  def read_absolute_x(self):
    return self.mread(self.indexed_absolute_addressing_x())

  def read_absolute_y(self):
    return self.mread(self.indexed_absolute_addressing_y())

  def read_indirect_x(self):
    return self.mread(self.indexed_indirect_addressing())

  def read_indirect_y(self):
    return self.mread(self.indirect_indexed_addressing())

  def read_immediate(self):
    old = self.PC; self.PC = self.PC + 1; self.PC &= 0xffff
    return self.prefetch_cue_get(old) or self.mread(old)

  #}}}
  ##########################################################
  #{{{ Flag methods
  ##########################################################
  for f_i, f_name in enumerate(FLAG_LIST):
    exec("%s_flag = flag_register('P', %d)" % (f_name, f_i))

  def flag_test(self, v):
    self.P = (self.P&~(FLAG_Z|FLAG_N)) | ZN_TABLE[v]

  def reset_flags(self, v): self.P &= ~v

  def set_flags(self, v): self.P |= v

  CLC = C_flag.fdel
  CLC.__name__ = "CLC"
  def SEC(self): self.C_flag = 1
  def SEI(self): self.I_flag = 1
  CLD = D_flag.fdel
  CLD.__name__ = "CLD"
  def SED(self): self.D_flag = 1
  CLV = V_flag.fdel
  CLV.__name__ = "CLV"
  
  #}}}
  ##########################################################
  #{{{ Store Op.
  ##########################################################
  def STA(self, w_addr):
    self.memory.write(w_addr, self.A)

  def STX(self, w_addr):
    self.memory.write(w_addr, self.X)

  def STY(self, w_addr):
    self.memory.write(w_addr, self.Y)

  #}}}
  ##########################################################
  #{{{ Load Op.
  ##########################################################
  def LDA(self, b_value):
    self.A = b_value & 0xff
    self.flag_test(self.A)

  def LDX(self, b_value):
    self.X = b_value & 0xff
    self.flag_test(self.X)

  def LDY(self, b_value):
    self.Y = b_value & 0xff
    self.flag_test(self.Y)

  #}}}
  ##########################################################
  #{{{ Stack Op.
  ##########################################################
  def push(self, b_value):
    self.memory.write(self.STACK_BASE|self.SP, b_value)
    self.SP = (self.SP - 1) & 0xff

  def pushw(self, w_value):
    self.push(w_value >> 8)
    self.push(w_value & 0xff)

  def pop(self):
    self.SP += 1
    self.SP &= 0xff
    return self.mread(self.STACK_BASE|self.SP)

  def popw(self):
    return self.pop() | (self.pop() << 8)

  def PHA(self):
    self.push(self.A)

  def PLA(self):
    self.LDA(self.pop())

  def PHP(self):
    self.push(self.P)

  def PLP(self):
    self.P = self.pop()
    self.R_flag = 1

  #}}}
  ##########################################################
  #{{{ Logical Op.
  ##########################################################
  def AND(self, v):
    self.A &= v & 0xff
    self.flag_test(self.A)

  def ORA(self, v):
    self.A |= v & 0xff
    self.flag_test(self.A)

  def EOR(self, v):
    self.A ^= v & 0xff
    self.flag_test(self.A)

  def BIT(self, v):
    self.P &= ~(FLAG_N|FLAG_Z|FLAG_C)
    if not (v & self.A):
      m = 0
    else:
      m = FLAG_Z
    self.P |= (v & (FLAG_N|FLAG_V)) | m
    self.P &= 0xff

  def _cmp(self, p, v):
    result = (p - v)&0xffff
    self.reset_flags(FLAG_N | FLAG_Z | FLAG_C)
    if result < 0x100  :
      m = FLAG_C
    else:
      m = 0
    self.set_flags(ZN_TABLE[result & 0xff] | m)

  def CMP(self, v):
    self._cmp(self.A, v)

  def CPX(self, v):
    self._cmp(self.X, v)

  def CPY(self, v):
    self._cmp(self.Y, v)

  #}}}
  ##########################################################
  #{{{ Math Op.
  ##########################################################

  def ADC(self, v):
    result = self.A + v + self.C_flag
    l = result & 0xff
    self.reset_flags(FLAG_N | FLAG_V | FLAG_Z | FLAG_C)
    self.set_flags((~(self.A^v)&(self.A^l)&0x80 and FLAG_V or 0) |
      (result > 0xff and FLAG_C or 0) |
      (ZN_TABLE[l]))
    self.A = l

  def SBC(self, v):
    word   = (self.A - v - (~self.P & FLAG_C))&0xffff
    l = word & 0xff
    self.reset_flags(FLAG_N | FLAG_V | FLAG_Z | FLAG_C)
    self.set_flags(((self.A^v)&(self.A^l) and FLAG_V or 0)|
      (word < 0x100 and FLAG_C or 0 )|
      (ZN_TABLE[l]))
    self.A = l

  def DEC(self, w_addr):
    v = self.mread(w_addr)
    v = (v-1)&0xff
    self.memory.write(w_addr, v)
    self.flag_test(v)

  def INC(self, w_addr):
    v = self.mread(w_addr)
    v = (v+1)&0xff
    self.memory.write(w_addr, v)
    self.flag_test(v)

  def _inc(self, n):
    setattr(self, n, (self.__getattribute__(n) + 1) & 0xff)
    self.flag_test(self.__getattribute__(n))

  def _dec(self, n):
    setattr(self, n, (self.__getattribute__(n) - 1) & 0xff)
    self.flag_test(self.__getattribute__(n))

  def INX(self): self._inc("X")

  def DEX(self): self._dec("X")

  def INY(self): self._inc("Y")

  def DEY(self): self._dec("Y")

  #}}}
  ##########################################################
  #{{{ Shift Op.
  ##########################################################

  def rs_by_addr(self, method_name, w_addr):
    v = self.mread(w_addr)
    v = self.__getattribute__(method_name)(v)
    self.memory.write(w_addr, v)

  def ASL(self, v):
    del self.C_flag
    self.P |= v >> 7
    self.P &= 0xff
    v <<= 1
    v &= 0xff
    self.flag_test(v)
    return v

  def LSR(self, v):
    del self.C_flag
    self.P |= v & FLAG_C
    self.P &= 0xff
    v >>= 1
    self.flag_test(v)
    return v

  def ROL(self, v):
    tmp = ((v<<1)|self.C_flag)&0xff
    del self.C_flag
    self.P |= tmp >> 7
    self.P &= 0xff
    v = tmp & 0xff
    self.flag_test(v)
    return v

  def ROR(self, v):
    P = self.P
    tmp = ((v>>1)|(P<<7))&0xff
    del self.C_flag
    P |= tmp & FLAG_C
    P &= 0xff
    self.P = P
    v = tmp
    self.flag_test(v)
    return v

  #}}}
  ##########################################################
  #{{{ Jump Op.
  ##########################################################
  def JMP(self, w_addr):
    self.PC = w_addr & 0xffff

  def JSR(self):
    old = self.PC; self.PC += 1; self.PC &= 0xffff
    w_addr = self.mread(old) | (self.mread(self.PC) << 8)
    self.pushw(self.PC)
    self.PC = w_addr

  def RTS(self):
    self.PC = (self.popw() + 1) & 0xffff

  #}}}
  ##########################################################
  #{{{ Conditional branching Op.
  ##########################################################
  def _bc(self, cond):
    if not cond:
      self.PC += 1; self.PC &= 0xffff
      return 2
    old = self.PC
    self.PC += byte2char(self.mread(self.PC))
    self.PC += 1
    self.PC &= 0xffff
    return 3 + ((old & 0x0100) != (self.PC & 0x100))

  def BCC(self): return self._bc(not self.C_flag)

  def BCS(self): return self._bc(self.C_flag)

  def BEQ(self): return self._bc(self.Z_flag)

  def BNE(self): return self._bc(not self.Z_flag)

  def BVC(self): return self._bc(not self.V_flag)

  def BVS(self): return self._bc(self.V_flag)

  def BPL(self): return self._bc(not self.N_flag)

  def BMI(self): return self._bc(self.N_flag)

  #}}}
  ##########################################################
  #{{{ Transfar Op.
  ##########################################################
  def TAX(self):
    self.X = self.A & 0xff
    self.flag_test(self.X)

  def TXA(self):
    self.A = self.X
    self.flag_test(self.A)

  def TAY(self):
    self.Y = self.A
    self.flag_test(self.Y)

  def TYA(self):
    self.A = self.Y
    self.flag_test(self.A)

  def TSX(self):
    self.X = self.SP
    self.flag_test(self.X)

  def TXS(self):
    self.SP = self.X

  #}}}
  #}}}
#}}}

