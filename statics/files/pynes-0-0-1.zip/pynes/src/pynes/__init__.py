# vim: fileencoding=utf-8
# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
__author__  = u"Yusuke Inuzuka"
__author_email__   = u"yuin@inforno.net"
__version__ = u"0.0.1"
__date__    = u"2007-03-01"

import sys
import os
import thread
import time
from common import *
from pynes.system import *
from pynes.pad     import *

class Pynes(object):
  def __init__(self):
    self.system = None
    self.rom_file_name = None

  def run(self, **options):
    if self.rom_file_name == None:
      raise StandardError("Cartridge is not set.")
    self.system = System(self.rom_file_name, **options)

    self.system.start()
    self.system.pad.listen()

  def insert_cartridge(self, rom_file_name):
    self.rom_file_name = rom_file_name

