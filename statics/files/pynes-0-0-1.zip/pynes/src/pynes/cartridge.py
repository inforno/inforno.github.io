# vim: fileencoding=utf-8
# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
from common import *
from pynes.ppu import *

#{{{ Cartridge
class InvalidROMError(StandardError):
  def __init__(self, name) : 
    StandardError.__init__(self, "%s is not a valid .NES file." % name)
class Cartridge(object):
  def __init__(self, fname):
    data = open(fname, "rb").read()
    info1 = unpack_byte(data[6:7])
    info2 = unpack_byte(data[7:8])
    info3 = unpack_byte(data[9:10])

    if data[0:4] != "NES\x1a" : raise InvalidROMError(fname)

    self.num_16k_prgrom   = unpack_byte(data[4:5])
    self.num_8k_vrom    = unpack_byte(data[5:6])
    self.num_8k_ram       = unpack_byte(data[8:9])
    self.mirroring        = info1 & 1
    # 1 for battery-backed RAM at $6000-$7FFF
    self.has_sram     = info1 & 0x02
    # 1 for a 512-byte trainer at $7000-$71FF
    self.has_trainer  = info1 & 0x04
    self.four_screen_vram_layout   = info1 & 0x08
    if self.four_screen_vram_layout:
      self.mirroring = PPU.MIRRORING_FOUR_SCREEN
    self.vs_system        = info2 & 1
    self.mapper_no        = (info2 & 0xf0) + (info1 >> 4)
    self.display          = info3 & 1
    bottom = 16
    if self.has_trainer:
      bottom = 16 + 512
      self.sram = [0]*0x1000 + unpack_bytes(data[16:bottom])
    else:
      self.sram = [0]*0x2000
    next = bottom+ self.num_16k_prgrom * 0x4000
    self.data_16k_prgrom = unpack_bytes(data[bottom:next])
    self.data_8k_vrom  = unpack_bytes(data[next:next+self.num_8k_vrom*0x2000])
  display_type = property(lambda self: self.display & 1 and "PAL" or "NTSC")

  def __str__(self):
    return ("\n"+"-"*60+"\n").join(map(lambda x: x[0].ljust(40)+"\t"+str(x[-1]), [
      ("Number of 16kB PRG-ROM banks",        self.num_16k_prgrom),
      ("Number of 8kB VROM banks",         self.num_8k_vrom),
      ("Number of 8kB RAM banks",             self.num_8k_ram),
      ("Mirroring", self.mirroring & 1 and "Vertical" or "Horizontal"),
      ("Battery-backed RAM at $6000-$7FFF? ", self.has_sram),
      ("512-byte trainer at $7000-$71FF?",    self.has_trainer),
      ("Four-screen VRAM layout?",            self.four_screen_vram_layout),
      ("VS-System cartridges?",               self.vs_system),
      ("Mapper no.",                          self.mapper_no),
      ("Display", self.display & 1 and "PAL" or "NTSC")
    ]))
#}}}

