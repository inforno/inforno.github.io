# vim: fileencoding=utf-8
# Copyright (c) 2007, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
import pygame
from pygame.locals import *
from common import *
from time import sleep

NES_PAD_A      = 0x80
NES_PAD_B      = 0x40
NES_PAD_SELECT = 0x20
NES_PAD_START  = 0x10
NES_PAD_UP     = 0x08
NES_PAD_DOWN   = 0x04
NES_PAD_LEFT   = 0x02
NES_PAD_RIGHT  = 0x01

class Pad(PartsBase):
  WAIT = 1/60

  def __init__(self, system):
    self.system = system
    self.input1_tmp = 0x00
    self.input1 = 0x00
    self.input2_tmp = 0x00
    self.input2 = 0x00
    self.latch  = False

    self.keymap1 = {
      K_UP : NES_PAD_UP,
      K_DOWN : NES_PAD_DOWN,
      K_LEFT : NES_PAD_LEFT,
      K_RIGHT : NES_PAD_RIGHT,
      K_KP0 : NES_PAD_START,
      K_KP_ENTER : NES_PAD_SELECT,
      K_KP2 : NES_PAD_B,
      K_KP3 : NES_PAD_A
    }

    self.keymap2 = {}

  def write(self, b_data):
    if self.latch and b_data == 1:
      self.input1_tmp = self.input1
      self.input2_tmp = self.input2
      self.input1 = 0x00
      self.input2 = 0x00
    self.latch = (b_data == 0)

  def read_pad1(self):
    ret = self.input1_tmp >> 0x7
    self.input1_tmp = (self.input1_tmp << 1) & 0xff
    return ret

  def read_pad2(self):
    ret = self.input2_tmp >> 0x7
    self.input2_tmp = (self.input2_tmp << 1) & 0xff
    return ret

  def listen(self):
    please_exit = False
    event_get = pygame.event.get
    wait = self.WAIT
    keymap1 = self.keymap1
    keymap1_keys = keymap1.keys()
    keymap2 = self.keymap2
    keymap2_keys = keymap2.keys()

    get_pressed = pygame.key.get_pressed
    while 1:
      got_event = False
      sleep(wait)
      if please_exit: break
      for event in event_get():
        got_event = True
        if event.type == QUIT:
          self.system.stop()
          please_exit = True
        elif event.type == KEYDOWN:
          if event.key == K_ESCAPE:
            self.system.stop()
            please_exit = True
          elif event.key in keymap1:
            self.input1 |= keymap1[event.key]
          elif event.key in keymap2:
            self.input2 |= keymap2[event.key]
          elif event.key == K_d:
            self.system.debug = not self.system.debug
          elif event.key == K_i:
            debugi(locals())
      if got_event: continue

      pressed_keys = get_pressed()
      for i in keymap1_keys:
        if pressed_keys[i]:
          self.input1 |= keymap1[i]
    return









