#!/usr/bin/python
#vim: fileencoding=utf8

# Copyright (c) 2008, Yusuke Inuzuka(http://inforno.net/)
# A Python library for NicoNio DOUGA
#
# License :
#   Artistic License 2.0

#built-in libraries
import sys
import re
import time
import datetime
import xml.dom.minidom as minidom
import math
from types import *
from os.path import join, exists
from os import makedirs
from urllib import urlopen,unquote,quote_plus,urlencode
from cgi import parse_qsl
from StringIO import StringIO
from itertools import *
from functools import *

# other libraries
import mechanize
from lxml import etree, objectify

#Error classes
############################################
class NicoError(StandardError): pass

class APIError(NicoError):
  def __init__(self, code, description):
    self.code = code
    self.description = description
    NicoError.__init__(self, "%s:%s"%(code,description))

class LoginError(NicoError): pass

# utilities
############################################
#string utilities
def tr(s, lst):
  return reduce(lambda r,v: r.replace(*v) or "", lst, s)

def underscore(s):
  return s[0].lower()+re.sub("([A-Z][^A-Z])", lambda m: "_"+m.group(1).lower(), s[1:])

def filename_escape(s):
  if sys.platform == "win32":
    return tr(s, [(u"\\", u"￥"), (u"/", u"／"), (u":", u"："), (u"*", u"＊"),
                  (u"?", u"？"),  (u"\"", u"”"),(u"<", u"＜"), (u">", u"＞"),
                  (u"|", u"｜")
                 ])
  else:
    return tr(s, [(u"/", u"／")])

def html_unescape(s):
  return tr(s, [(u'&gt;', u'>'), (u'&lt;', u'<'), (u'&quot;', u'"'), (u'&amp;', u'&')])

def bytes_to_str(num):
  e = int(math.log(num, 1024))
  return "%.2f%s"%(num/float(1024**e), "bkMGTPEZY"[e])

#math utilities
def zero_safe_div(v1, v2, eps = 1e-7):
  if abs(v2) < eps: return 0
  return v1/v2

# html and xml utilities
import warnings
warnings.simplefilter('ignore', UserWarning)
etree.parse(StringIO("<a></a>"), etree.HTMLParser()).xpath("//a")
warnings.simplefilter('default', UserWarning)

def xml_to_dict(xml_raw_text, to_under=True):
  class XmlUnicode(unicode): pass
  class XmlDict(dict): pass
  def attrs_to_dict(elm):
    if not hasattr(elm.attributes, "_attrs"): return {}
    return dict([(k, v.value) for k, v in elm.attributes._attrs.iteritems()])

  dct = dict()
  filter = to_under and underscore or (lambda s:s)
  def _(elm, data) :
    name = filter(elm.nodeName)
    if name=="#text": return
    children_size = len(elm.childNodes)
    if children_size == 0 :
      value = XmlUnicode(u"")
    elif children_size == 1 and elm.childNodes[0].nodeType == minidom.Node.TEXT_NODE :
      value = XmlUnicode(elm.childNodes[0].data)
    else :
      value = XmlDict([])
      for child in elm.childNodes : _(child, value)
    setattr(value, "attrs", attrs_to_dict(elm))
    node = data.get(name)
    if node :
      if not isinstance(node, list):
        data[name] = [data[name]]
      data[name].append(value)
    else:
      data[name] = value
  _(minidom.parseString(xml_raw_text), dct)
  return dct["#document"]

#slice utilities
def get_index_by_slice(s, obj):
  length = len(obj)
  start = s.start if s.start is not None else 0
  stop  = s.stop  if s.stop is not None else length
  step  = s.step  if s.step is not None else 1
  if start < 0: start = length + start
  if stop < 0: stop = length + stop
  return (start, stop, step)

#list utilities
pos = lambda lst, v: lst[v]
cdr = lambda lst: lst[1:]
car = fst = partial(pos, v=0)
snd = partial(pos, v=1)

#Main classes
############################################
#Downloaders
######################
class Downloader(object):
  def __init__(self): pass

  def set_response(self, response):
    if isinstance(response, ("".__class__, u"".__class__)):
      self._response = urlopen(response)
    else:
      self._response = response
  response = property(lambda s:s._response, set_response)

  def get_content_lendth(self):
    try:
      return int(self.response.info().getheader("content-length")) 
    except:
      return 0
  content_length = property(get_content_lendth)

  def start(self, response, to):
    self.response = response
    for _ in self.download_blocks(to): pass

  def get_default_name(self, value=None):
    parts = self.response.geturl().split("/")
    return value or parts[-1] or parts[-2] or "data.out"

  def download_blocks(self, to=None, blocksize=1024**2):
    _blocksize = blocksize
    bps = _blocksize
    out = open(self.get_default_name(to), "wb")
    downloaded_bytes = 0
    while True:
      start = time.time()
      data = self.response.read(_blocksize)
      term = time.time() - start
      out.write(data)
      bytes = len(data)
      if bytes != 0:
        bps = zero_safe_div(bytes, float(term))
        downloaded_bytes += bytes 
      yield downloaded_bytes
      if bytes == 0: break

      new_min = int(max(bytes / 2.0, 1.0))
      new_max = int(max(bytes * 2.0, 1.0))
      if term < 1e-7 or bps > new_max:
        _blocksize = new_max
      elif bps < new_min:
        _blocksize = new_min
      else:
        _blocksize = int(bps)


class SimpleDownloader(Downloader):
  def __init__(self, bar="=", barwidth=20):
    Downloader.__init__(self)
    self.bar = bar
    self.barwidth = barwidth
    self.unknown = "unknown"

  def start(self, response, to=None):
    self.response = response
    content_length   = self.content_length
    percentage_width = len(self.unknown) if content_length == 0 else 4
    to = self.get_default_name(to)
    percentage = self.unknown
    total = self.unknown
    bar = ""
    eta = "--:--:--"

    sys.stdout.flush()
    start = time.time()
    print "Downloading %s to %s"%(self.response.geturl(), to)
    for downloaded_bytes in self.download_blocks(to):
      bps = zero_safe_div(downloaded_bytes, float(time.time() - start))
      if content_length:
        eta = zero_safe_div((content_length - downloaded_bytes), bps)
        eta = time.strftime('%H:%M:%S', time.gmtime(eta))
        percentage = str(100 * downloaded_bytes / content_length)+"%"
        total = bytes_to_str(content_length)
        bar = self.bar * (self.barwidth * downloaded_bytes / content_length)
      print ("\r%s |%-*s| %7s/%7s ETA: %*s [%7s/s]"%\
          (percentage.rjust(percentage_width), self.barwidth, bar, \
           bytes_to_str(downloaded_bytes), total, 8, eta, bytes_to_str(bps))),
      sys.stdout.flush()
    print
#Pages
######################
class NicoPage(object):
  def __init__(self, io):
    self.html  = io.read().decode("utf8", 'ignore')
    self.xpath = etree.parse(StringIO(self.html), etree.HTMLParser()).xpath

  def element_text(self, elem):
    result = [elem.text or u""]
    for e in elem:
      result.append(self.element_text(e))
      if e.tail:
        result.append(e.tail)
    return u"".join(result)

class VideoListPage(NicoPage):
  LIST_MAX_PER_PAGE = 1 #abstract
  VIDEO_XPATH = "" # abstract
  def get_list_len(self):
    raise NotImplementedError
  def get_videos(self):
    result = []
    for a in self.xpath(self.VIDEO_XPATH):
      title = html_unescape(a.text)
      id    = a.attrib["href"].split("/")[-1]
      result.append(Video(id=id, client=None, meta={"title":title}))
    return result

class NullVideoListPage(VideoListPage):
  def __init__(self): pass
  def get_videos(self): return []
  def get_list_len(self): return 0

class GridVideoListPage(VideoListPage):
  LIST_MAX_PER_PAGE = 30
  VIDEO_XPATH = '//p[@class="TXT12"]/a[@class="video"]'

  def get_list_len(self):
    if not self.get_videos():
      return 0
    return int(self.xpath("//form[@name='sort']/table[1]/tr[1]/td[1]/strong[1]")[0].text.replace(",", ""))

class VideoSearchResultPage(GridVideoListPage): pass
class VideoNewarrivalPage(GridVideoListPage): 
  def get_list_len(self):
    #TODO
    return 1000
class VideoRandomPage(GridVideoListPage): 
  LIST_MAX_PER_PAGE = 50
  def get_list_len(self):
    return 50

class VerticalVideoListPage(VideoListPage):
  LIST_MAX_PER_PAGE = 100
  VIDEO_XPATH = '//h3/a[@class="video"]'
  def get_list_len(self): return 300

class VideoRankingPage(VerticalVideoListPage): pass
class VideoMylistPage(VerticalVideoListPage):
  #TODO
  LIST_MAX_PER_PAGE = 500
  def get_list_len(self):
    return len(self.get_videos())


#Client
######################
class NicoClient(object):
  URL_BASE = "http://www.nicovideo.jp/"

  URL_LOGIN = "https://secure.nicovideo.jp/secure/login?site=niconico"
  NEVER_DELETE = "sm9"

  def __init__(self, mail, password, cookie_file="", cookie_type="Mozilla", download_dir=None, interval = 1, downloader=None):
    self.mail = mail
    self.password = password
    self.cookie_file = cookie_file
    self.download_dir = download_dir or u"./download"
    self.interval = max(interval, 1)
    self.downloader = downloader or SimpleDownloader()
    #lazy
    self._nickname = ""
    self._user_id  = ""
    self._is_premium = None
    # my browser
    self.br = mechanize.Browser()

    if cookie_file:
      self.cookie_jar = eval("mechanize.%sCookieJar()"%cookie_type)
      self.cookie_jar.load(self.cookie_file)
      self.br.set_cookiejar(self.cookie_jar)

  def is_authenticated(self, res = None):
    res = res or self.br._response
    if res.info().getheader("x-niconico-authflag") == "1":
      return True
    return False

  def open(self, url, data=None):
    time.sleep(self.interval)
    if isinstance(data, DictType): 
      data = urlencode(data.items())
    res = self.br.open(url, data)
    if not self.is_authenticated(res):
      self.login()
      time.sleep(self.interval)
      res = self.br.open(url, data)
    return res

  def login(self):
    res = self.br.open(self.URL_LOGIN, urlencode({"mail":self.mail, "password":self.password}.items()))
    if not self.is_authenticated(res):
      raise LoginError(u"Login failed with %s"%(self.mail))
    return True

  def _init_user_infomation(self):
    meta = Video(self, self.NEVER_DELETE).meta
    self._nickname = meta["nickname"]
    self._user_id  = meta["user_id"]
    self._is_premium = bool(meta["is_premium"])

  def _init_user_infomation_if_need(self):
    if not self._nickname:
      self._init_user_infomation()

  def get_nickname(self):
    self._init_user_infomation_if_need()
    return self._nickname
  nickname = property(get_nickname)

  def get_user_id(self):
    self._init_user_infomation_if_need()
    return self._user_id
  user_id = property(get_user_id)

  def get_is_premium(self):
    self._init_user_infomation_if_need()
    return self._is_premium
  is_premium = property(get_is_premium)

class NicoClientExtensionType(type):
  def __new__(cls, cls_name, cls_bases, cls_dict):
    cls = type.__new__(cls, cls_name, cls_bases, cls_dict)
    setattr(NicoClient, underscore(cls_name), lambda s, *a, **k: cls(s, *a, **k))
    return cls

class NicoClientExtension(object):
  __metaclass__ = NicoClientExtensionType

class IterableVideoListPageAction(object):
  PAGE = "" #abstract
  def __init__(self, client):
    self.page   = 1
    self.client = client
    self.current_list_page = None

  def get_list_page(self):
    raise NotImplementedError

  def get_max_per_page(self): return self.PAGE.LIST_MAX_PER_PAGE

  def __len__(self):
    if not self.current_list_page:
      self.current_list_page = self.get_list_page()
    return self.current_list_page.get_list_len()

  def __iter__(self):
    return imap(snd, self.iter_from())

  def iter_from(self, index = 0):
    page, i = self.get_start_page_index(index)
    self.page = page
    while 1:
      self.current_list_page = self.get_list_page()
      videos = self.current_list_page.get_videos()
      if not videos: raise StopIteration
      for video in videos:
        if i >= index:
          video.client = self.client
          yield (i, video)
        i = i + 1
      self.page += 1

  def get_start_page_index(self, i):
    if not isinstance(i, (int, long)): raise TypeError
    from_page = int(i/self.get_max_per_page()) + 1
    return (from_page, (from_page - 1)*self.get_max_per_page())

  def __getitem__(self, k):
    if isinstance(k, slice):
      start, stop, _ = get_index_by_slice(k, self)
      return map(snd, takewhile(lambda v: v[0] < stop, self.iter_from(start)))

    if isinstance(k, (int, long)) and k < 0: 
      k = len(self) + k
    for (i, video) in self.iter_from(k): return video
    raise IndexError

#Video Extension
######################
class Video(NicoClientExtension):
  URL_WATCH = NicoClient.URL_BASE + "watch/%s"
  URL_API_GET_FLV = NicoClient.URL_BASE + "api/getflv/%s"
  URL_API_GET_THUMB_INFO = NicoClient.URL_BASE + "api/getthumbinfo/%s"

  FILE_TYPE_RE = re.compile(".*/smile\?([a-z]{1})\=.*")

  def __init__(self, client, id, meta = None):
    self.client = client
    self.id = id
    self.meta = meta or {}

  def __getattr__(self, key):
    if key in self.meta:
      return self.meta[key]
    return self.__getattribute__(key)

  def get_meta(self):
    key = self._meta.keys()
    if len(key) == 0:
      self.update_meta()
    else:
      if len(key) == 1 and key[0] == "title":
        self.update_meta()
    return self._meta

  def set_meta(self, v):
    self._meta = v
  meta = property(get_meta, set_meta)

  def get_title(self):
    if "title" not in self._meta:
      self.update_meta()
    return self._meta.get("title", None)
  title = property(get_title)

  def update_meta(self):
    id = self.id
    thumb_info = xml_to_dict(self.client.open(self.URL_API_GET_THUMB_INFO%id).read())["nicovideo_thumb_response"]
    if "error" in thumb_info:
      e = thumb_info["error"]
      raise APIError(e["code"], "%s(%s)"%(e["description"], id))

    result = thumb_info["thumb"]
    def convert(name, f = int): result[name] = f(result[name])
    convert("first_retrieve", lambda v:datetime.datetime.strptime(v[:-6], "%Y-%m-%dT%H:%M:%S"))
    result["posted_at"] = result["first_retrieve"]
    try:
      result["tags"] = result["tags"]["tag"]
    except:
      result["tags"] = result["tags"][0]["tag"]
    def _(v):
      return datetime.time(*[(m/60, m%60, s) for (m,s) in [map(int, v.split(":"))]][0])
    convert("length", _)
    result.update(dict(parse_qsl(self.client.open(self.URL_API_GET_FLV%id).read())))
    match = self.FILE_TYPE_RE.match(result["url"])
    result["file_type"] = {"m": "mp4", "v": "flv", "s": "swf"}. \
                          get(match and match.group(1) or "", "unknown")
    for key, value in result.iteritems():
      if getattr(value, "isdigit", lambda : False)() and not key.endswith("_id"):
        convert(key)

    self.meta = result

  def _get_comments_io(self, n=500):
    #TODO support premium users
    data = u"<thread res_from=\"-%d\" version=\"20061206\" thread=\"%s\" />"%(n, self.thread_id)
    return self.client.open(self.ms, data)

  def get_comments_raw_xml(self, *a):
    return self._get_comments_io(*a).read()

  def get_comments(self, *a):
    return xml_to_dict(self.get_comments_raw_xml())

  def get_is_economy(self):
    return self.url.endswith("low")
  is_economy = property(get_is_economy)

  def download(self, format=u"%(title)s[%(video_id)s].%(file_type)s", with_comments=False, comments_num=500):
    if not exists(self.client.download_dir):
      makedirs(self.client.download_dir)
    local_path = join(self.client.download_dir, filename_escape(format%self.meta))
    self.client.open(self.URL_WATCH%self.id)
    res = self.client.open(self.url)
    self.client.downloader.start(res, local_path)
    if with_comments:
      comment_local_path = re.sub("\.\w+$", ".xml", local_path)
      self.client.downloader.start(self._get_comments_io(comments_num), comment_local_path)
      return (local_path, comment_local_path)
    return local_path


  def __repr__(self):
    return u"Video(%s)"%str(self.meta)

#Search Extension
######################
ORDER_ASC = "a"
ORDER_DESC= ""
SORT_POSTED_AT = "a"
SORT_NUM_VIEWS = "v"
SORT_COMMENTED_AT = "n"
SORT_NUM_COMMENTS = "r"
SORT_NUM_MYLISTS = "m"
SEARCH_KEYWORD = "search"
SEARCH_TAG="tag"

class VideoSearch(IterableVideoListPageAction, NicoClientExtension):
  URL_SEARCH = NicoClient.URL_BASE + "%s/%s?sort=%s&order=%s&page=%d"
  PAGE = VideoSearchResultPage
  def __init__(self, client, q, by=SEARCH_KEYWORD, sort=SORT_POSTED_AT, order=ORDER_DESC):
    self.q = q
    self.by = by
    self.sort = sort
    self.order = order
    IterableVideoListPageAction.__init__(self, client)

  def get_list_page(self):
    url = self.URL_SEARCH%(self.by, quote_plus(self.q.encode("utf8")), self.sort, self.order, self.page)
    return self.PAGE(self.client.open(url))

#Ranking Extension
######################
RANKING_MYLIST = "mylist"
RANKING_VIEW = "view"
RANKING_COMMENT = "res"

RANKING_DAILY = "dialy"
RANKING_NEWARRIVAL   = "newarrival"
RANKING_WEEKLY = "weekly"
RANKING_MONTHLY = "monthly"
RANKING_TOTAL = "total"
class VideoRanking(IterableVideoListPageAction, NicoClientExtension):
  URL_RANKING = NicoClient.URL_BASE + "ranking/%s/%s/%s?page=%d"
  PAGE = VideoRankingPage
  def __init__(self, client, by=RANKING_MYLIST, span=RANKING_DAILY, category="all"):
    self.by = by
    self.span = span
    self.category = category
    IterableVideoListPageAction.__init__(self, client)

  def get_list_page(self):
    url = self.URL_RANKING%(self.by, self.span, self.category, self.page)
    return self.PAGE(self.client.open(url))

#Newarrival Extension
######################
class VideoNewarrival(IterableVideoListPageAction, NicoClientExtension):
  URL_NEWARRIVAL = NicoClient.URL_BASE + "newarrival?page=%d"
  PAGE = VideoNewarrivalPage
  def get_list_page(self):
    url = self.URL_NEWARRIVAL%(self.page)
    return self.PAGE(self.client.open(url))

#Mylist Extension
######################
class VideoMylist(IterableVideoListPageAction, NicoClientExtension):
  URL_MYLIST = NicoClient.URL_BASE + "mylist/%s"
  PAGE = VideoMylistPage
  def __init__(self, client, mylist_id):
    self.mylist_id = mylist_id
    IterableVideoListPageAction.__init__(self, client)

  def get_list_page(self):
    if self.page > 1:
      return NullVideoListPage()
    url = self.URL_MYLIST%(str(self.mylist_id))
    return self.PAGE(self.client.open(url))

#Random Extension
######################
class VideoRandom(IterableVideoListPageAction, NicoClientExtension):
  URL_RANDOM = NicoClient.URL_BASE + "random"
  PAGE = VideoRandomPage
  def get_list_page(self):
    if self.page > 1:
      return NullVideoListPage()
    return self.PAGE(self.client.open(self.URL_RANDOM))
