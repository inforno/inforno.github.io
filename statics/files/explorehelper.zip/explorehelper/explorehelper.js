var $ADIR_PATH = "getahwnd.exe";

/*****************************************************************
 * Prototype extensions
 *****************************************************************/
new function(){
  var extend = function(dest, src){for(var i in src){dest[i] = src[i];};return dest;};
  extend(Function.prototype, {
    _singleton : function(){
      var self = this;
      return function(){
        if(!arguments.callee.instance) arguments.callee.instance = self();
        return arguments.callee.instance; }
    },

    _item_proc : function(){
      var self = this;
      return function(){
        var path = get_dir_and_focused_item();
        if(!path.item) return MessageBox("�t�@�C�����I������Ă��܂���B");
        self();
      };
    },

    _auto_win_activate : function(){
      var self = this;
      return function(){ self(); win_activate(); }
    }
  });
  extend(String.prototype, {
    _decode_location : function(){
      return decodeURIComponent(this).replace("file:///","").split("/").join("\\");
    },

    _join_path : function(){
      var ret = (this.slice(-1) == "\\") ? this.slice(0,-1) : this.slice(0);
      return Array.prototype.concat.apply([ret], arguments).join("\\");
    },

    _base_name : function(){
      return ((this.slice(-1) == "\\") ? this.slice(0,-1) : this.slice(0)).split("\\").pop();
    },

    _as_path_escaped : function(){
      var ret = this.slice(0);
      if(ret.indexOf(" ") > 0) return ['"', ret, '"'].join("");
      return ret;
    }
  });

  Enumerator.prototype._to_a = function(){
    for (var ret=[]; !this.atEnd(); this.moveNext()) ret.push(this.item());
    return ret;
  }

}

/*****************************************************************
 * UI components
 *****************************************************************/
var InputBox = null;
new function(){
  var sc = new ActiveXObject("ScriptControl");
  sc.Language = "VBScript";
  sc.AddCode("Function ip(prompt, title, default)\nip = InputBox(prompt, title, default)\nEnd Function\n"); 
  InputBox = function(p, d, t){ return sc.Run("ip", p, t, d);}
}

var MessageBox = function(msg){ WScript.echo(msg); }

var Confirm = function(msg){ return wscript_shell().Popup(msg, 0,"", 1 + 32) == 1; }

/*****************************************************************
 * Main functions
 *****************************************************************/
var shell = function(){
  return new ActiveXObject("Shell.Application");
}._singleton();

var wscript_shell = function(){
  return new ActiveXObject("WScript.Shell");
}._singleton();


var fs = function(){
  return new ActiveXObject("Scripting.FileSystemObject");
}._singleton();


var win_activate = function(){wscript_shell().AppActivate(get_dir_and_focused_item_path().win);};

var get_active_hwnd = function(){
  return parseInt(wscript_shell().Exec($ADIR_PATH).StdOut.ReadAll());
}._singleton();

var get_active_dir = function(){
  var target_hwnd = get_active_hwnd();
  if(!target_hwnd) return null;
  var windows = (new Enumerator(shell().Windows()))._to_a();
  for(var i=0,l=windows.length; i<l; i++){
    if(windows[i].hwnd == target_hwnd) return windows[i]
  }
  return null;
}._singleton();

var get_dir_and_focused_item = function(){
  var win = get_active_dir();
  if(!win) return {win:null, item:null};
  return {win:win, item:win.Document.FocusedItem};
}._singleton();

var get_dir_and_focused_item_lst = function(){
  var win = get_active_dir();
  if(!win) return {win:null, items:[]};
  if(!win.Document.FocusedItem) return {win:win, items:[]};
  var items = (new Enumerator(win.Document.SelectedItems()))._to_a();
  return {win:win, items:items};
}._singleton()

var get_dir_and_focused_item_path = function(){
  var obj = get_dir_and_focused_item();
  if(!obj.win) return {win:"", item:""};
  var dir_path = obj.win.LocationURL._decode_location();
  var item_path = obj.item ? dir_path._join_path(obj.item.name) : "";
  return {win:dir_path, item:item_path};
}._singleton();

var get_dir_and_focused_item_path_lst = function(){
  var obj = get_dir_and_focused_item_lst();
  if(!obj.win) return {win:"", items:[]};
  var dir_path = obj.win.LocationURL._decode_location();
  for(var i=0,l=obj.items.length, result=[]; i<l; i++) {
    result.push(dir_path._join_path(obj.items[i].name));
  }
  return {win:dir_path, items:result};
}._singleton();

var $wsh_args = []
new function(){for(var i=0,l=WScript.Arguments.length; i<l; i++) $wsh_args.push(WScript.Arguments(i));}

var run = function(procs){
  if(!get_active_hwnd()) return;
  var name = ($wsh_args[0] || "").toLowerCase();
  ((name in procs) ? procs[name] : procs.proc_default)();
}

