# vim:fileencoding=utf-8
#
# Lingr - Lingr library for python
# Copyright (c) 2006, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Articstic License 2.0
#
# Synopsis:
#
#   lingr = Lingr("your api_key")
#   lingr.api.session.create()
#   lingr.api.room.enter(id="room id", nickname="nickname")
#   lingr.api.romm.say(message="hello!")
#   lingr.api.room.exit()
#   lingr.api.session.destroy()
#
#   result = lingr.api.explore.search(q=scheme)
#   print result.rooms
#
#   You can call API methods via the "api" property.
#   API methods parameters are passed as keyword arguments.
#   Note that "api_key", "session", "ticket" for user.* methods,
#   and "ticket" for room.* methods, these parameters are
#   automatically passed.
#

__author__  = u"Yusuke Inuzuka"
__author_email__   = u"yuin@inforno.net"
__version__ = u"0.1"
__date__    = u"2007-02-01"
__all__     = ["Lingr", "Error", "ApiError"]

import sys
import os
import urllib2
from sets import Set
import xml.dom.minidom as minidom
import re
from urllib import urlencode

def urlparam(dict) :
  return urlencode(dict.items())

def underscore(s):
  return underscore.m.sub(underscore.f, s)
underscore.m = re.compile("([A-Z])")
underscore.f = lambda match: "_"+match.group(0).lower()

BASE_URL = u"http://www.lingr.com"

class Storage(dict):
    def __getattr__(self, key): 
        if self.has_key(key): 
            return self[key]
        raise AttributeError, repr(key)
    def __setattr__(self, key, value): 
        self[key] = value
    def __repr__(self):     
        return '<Storage ' + dict.__repr__(self) + '>'

class Error(StandardError):
  def __init__(*args):
    StandardError.__init__(*args)

class ApiError(Error):
  def __init__(self, code, message):
    Error.__init__(self, u"Lingr API error:\n code: %s\n message: %s\n" % (code, message))

class Api(object) :
  REST_END_POINT = BASE_URL + u"/api"

  def __init__(self): pass

  def call(self, method, http_method="POST", *dummy, **params) :
    url = self.REST_END_POINT + u"/" + method
    params = urlparam(params)
    if http_method == "POST":
      data = urllib2.urlopen(url, params).read()
    else:
      data = urllib2.urlopen(url+u"?"+params).read()
    return self.Result(data)

  class Result(object) :
    def __init__(self, raw_xml) :
      self.doc = minidom.parseString(raw_xml)
      self.parse_data()
      self.check_error()

    def check_error(self) :
      if self.is_failed:
        raise ApiError(self.error.code, self.error.message)

    def parse_data(self) :
      all_data = dict()
      def func(elm, data) :
        is_arr = False
        name = elm.nodeName
        node = data.get(name)
        if node :
          is_arr = True
          if not isinstance(node, [].__class__):
            data[name] = [data[name]]
        children_size = len(elm.childNodes)
        if children_size == 0 :
          value = ""
        elif children_size == 1 and elm.childNodes[0].nodeType == minidom.Node.TEXT_NODE :
          value = elm.childNodes[0].data
        else :
          value = dict()
          for child in elm.childNodes :
            func(child, value)
          value = Storage(value)
        if is_arr :
          data[name].append(value)
        else :
          data[name] = value
      func(self.doc, all_data)
      self.data = Storage(all_data["#document"][u"response"])
      self.is_failed = self.data.status != u"ok"

    def __getattr__(self, key): 
      if self.data.has_key(key): 
        return self.data[key]
      raise AttributeError, repr(key)

    def __repr__(self):     
        return '<lingr.Result ' + dict.__repr__(self.data) + '>'

class Lingr(object):
  _HTTP_METHOD_GET = Set([
                    "explore.getHotRooms",
                    "explore.getNewRooms",
                    "explore.getHotTags",
                    "explore.getAllTags",
                    "explore.search",
                    "explore.searchTags",
                    "user.getInfo",
                    "user.observe",
                    "room.getInfo",
                    "room.getMessages",
                    "room.observe"
                     ])
  _NEED_API_KEY  = Set([
                    "session.create",
                    "explore.getHotRooms",
                    "explore.getNewRooms",
                    "explore.getHotTags",
                    "explore.getAllTags",
                    "explore.search",
                    "explore.searchTags",
                    "room.getInfo"
                  ])
  _NEED_SESSION = Set([
                    "session.destroy",
                    "auth.login",
                    "auth.logout",
                    "user.getInfo",
                    "user.startObserving",
                    "user.observe",
                    "user.stopObserving",
                    "room.enter",
                    "room.getMessages",
                    "room.observe",
                    "room.setNickname",
                    "room.say",
                    "room.exit"
                  ])
  _NEED_ROOM_TICKET = Set([
                    "room.getMessages",
                    "room.observe",
                    "room.setNickname",
                    "room.say",
                    "room.exit"
                  ])
  _NEED_USER_TICKET = Set([
                    "user.observe",
                    "user.stopObserving"
                  ])

  def __init__(self, api_key):
    self.api_key = api_key
    self._api = Api()
    lingr = self
    class ApiWrapper(object) :
      class _element(object) :
        def __init__(self, key) :
          self.key = key
        def __getattr__(self, key) :
          return self.__class__(".".join([self.key, key]))
        def __call__(self, *args, **keywords) :
          if self.key in lingr._HTTP_METHOD_GET:
            keywords["http_method"] = "GET"

          if self.key in lingr._NEED_API_KEY:
            keywords["api_key"] = lingr.api_key
          if self.key in lingr._NEED_SESSION:
            keywords["session"] = lingr.session

          if self.key in lingr._NEED_ROOM_TICKET:
            keywords["ticket"] = lingr.room_ticket
          elif self.key in lingr._NEED_USER_TICKET:
            keywords["ticket"] = lingr.user_ticket
          key = underscore(self.key.replace(".", "/"))
          method_name = key.replace("/", "_")
          if hasattr(lingr, method_name):
            return getattr(lingr, method_name)(**keywords)
          return lingr._api.call(key, **keywords)

      def __init__(self): pass
      def __getattr__(self, key):
        return self._element(key)
    self.api = ApiWrapper()
    self.session = None
    self.user_ticket = None
    self.room_ticket = None

  def session_create(self, **keywords):
    result = self._api.call("session/create", **keywords)
    self.session = result.session
    return result

  def session_destroy(self, **keywords):
    result = self._api.call("session/destroy", **keywords)
    self.session = None
    return result

  def user_start_observing(self, **keywords):
    result = self._api.call("user/start_observing", **keywords)
    self.user_ticket = result.ticket
    return result

  def room_enter(self, **keywords):
    result = self._api.call("room/enter", **keywords)
    self.room_ticket = result.ticket
    return result
