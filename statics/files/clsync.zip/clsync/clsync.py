#!/usr/bin/env python
# vim: fileencoding=utf-8
import sys
import commands
import socket
import optparse

HOST_IP       = "192.168.0.100"
HOST_PORT     = 46758
parser = optparse.OptionParser()
parser.add_option("-i", "--ip" , dest="host", help= 'host ip.', default= HOST_IP)
parser.add_option("-p", "--port" , dest="port", help= 'host port.', default= HOST_PORT)

(options, args) = parser.parse_args()

if not args:
  text = sys.stdin.read()
elif len(args) == 1:
  text = args[0]
else:
  parser.print_help()

cmd  = "".join(["echo '", text.replace("'", "'\"'\"'"), "' | nkf -Lw -s -Bx"])
text = commands.getoutput(cmd)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(10)
try:
  s.connect((options.host, options.port))
  s.send(text[0:-3])
  s.close()
except socket.error, e:
  print e
