#vim: fileencoding=utf8
# Copyright (c) 2009, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Artistic License 2.0
from __future__ import with_statement
import hashlib
import sys
import time
import socket
import traceback
import select
import json
import random 
try:
  import threading
except ImportError:
  import dummy_threading as threading
try:
  import cmath as math
except ImportError:
  import math

# Utilities {{{
DEBUG = False
def debug_print(*args):
  if not DEBUG: return
  with debug_print.lock:
    debug_print.seq += 1
    init = ["%s:%d"%(str(threading.current_thread().name), debug_print.seq)]
    sys.stdout.write(u" ".join(reduce(lambda a,b: a.append(unicode(b)) or a, args, init)))
    sys.stdout.write("\n-----------------------------------------------------\n")
debug_print.seq = -1
debug_print.lock = threading.Lock()
# }}}

# KBucket {{{
class KBucket(list):
  def __init__(self, k):
    self.k = k

  def __repr__(self):
    return "<%s %s>"%(self.__class__.__name__, list.__repr__(self))

  def is_full(self):
    return len(self) >= self.k

  def has_node(self, node):
    return [True for contact in self if contact == node]
  __contains__ = has_node

  def check(fname):
    def _(self, value):
      if not isinstance(value, ContactNode):
        raise TypeError("must be ContactNode")
      if self.is_full():
        raise StandardError("full")
      return getattr(list, fname)(self, value)
    return _

  append = check("append")
  __setitem__ = check("__setitem__")
# }}}

# RoutingTable {{{
class RoutingTable(object):
  def __init__(self, node, k = 20):
    self.node = node
    self.k = k
    self.lock = threading.Lock()
    self.table = [KBucket(k) for _ in xrange(self.node.HASH_SIZE)]

  def __repr__(self):
    tpl = "<%s k:%d\n%s>"
    table_str = []
    for i, k_bucket in enumerate(self.table):
      table_str.append("  %03d %s"%(i, repr(k_bucket)))
    return tpl%(self.__class__.__name__, self.k, "\n".join(table_str))

  def __iter__(self):
    for k_bucket in self.table:
      for contact in k_bucket:
        yield contact

  def close_k_bucket_index(self, node_or_id):
    node_id = getattr(node_or_id, "node_id", node_or_id)
    distance = self.node ^ node_id
    try:
      return int(abs((math.log(distance, 2))))
    except:
      return 0

  def learn_new_contact(self, contact):
    with self.lock:
      index = self.close_k_bucket_index(contact)
      k_bucket = self.table[index]
      if contact in k_bucket:
        # move to the tail of list
        k_bucket.remove(contact)
        k_bucket.append(contact)
      elif k_bucket.is_full():
        if self.node.raw_ping(k_bucket[0]):
          least_recently_seen_node = k_bucket.pop(0)
          k_bucket.append(least_recently_seen_node)
        else:
          k_bucket.pop(0)
          k_bucket.append(contact)
      else:
        k_bucket.append(contact)

  def remove_contact(self, contact):
    with self.lock:
      index = self.close_k_bucket_index(contact.node_id)
      try:
        self.table[index].remove(contact)
      except:
        pass

  def close_k_contacts(self, node_id):
    with self.lock:
      try:
        index = self.close_k_bucket_index(node_id)
        result   = set(self.table[index])
        for i in xrange(1, self.node.HASH_SIZE):
          result |= set(self.table[min(self.node.HASH_SIZE-1, index+i)])
          result |= set(self.table[max(0,   index-i)])
          if len(result) >= self.k:
            break
      except Exception, e:
        result = set([])
    return sorted(list(result), cmp = lambda a,b: cmp(a ^ node_id, b ^ node_id))

# }}}

# Index {{{
class Index(dict):
  def __init__(self, node, ttl = 60*60*24):
    self.node = node
    self.ttl  = ttl

  def get_value(self, key):
    return super(Index, self).__getitem__(key)[0]
  __getitem__ = None

  def set_value(self, key, value):
    return super(Index, self).__setitem__(key, (value, time.time()))
  __setitem__ = None

  iteritems = None
  items = None

  def expires(self):
    now = time.time()
    for k in (k for k in self if (now - self[k][1]) > self.ttl):
      del self[k]
# }}}

# TCPServer {{{
class TCPServer(object):
  def __init__(self, address, on_receive):
    self.address = address
    self.on_receive = on_receive
    self.running = False

  def is_stopped(self): return not self.running

  def stop(self):
    if getattr(self, "thread", None) and self.thread.is_alive():
      self.running = False
      self.thread.join()

  def start(self):
    if not self.is_stopped():
      return
    self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    self.sock.bind(self.address)
    self.sock.listen(5)
    self.running = True
    def run(self):
      rs= [self.sock]
      addresses = []
      while self.running:
        rsocks, wsocks, esocks = select.select(rs, [], [], 1.0)
        for rsock in rsocks:
          if rsock == self.sock:
            conn, address = self.sock.accept()
            rs.append(conn)
            addresses.append([conn, address])
          else:
            conn = rsock
            try:
              message = conn.recv(8192)
            except:
              message = None
              
            index = [i for i,a in enumerate(addresses) if a[0] == conn][0]
            if not message:
              del addresses[index]
              del rs[rs.index(conn)]
              conn.close()
            else:
              threading.Thread(target = self.on_receive, args = (message, conn, addresses[index][1])).start()
      self.sock.close()
    self.thread = threading.Thread(target = run, args = (self,))
    self.thread.setDaemon(True)
    self.thread.start()
# }}}

# BaseNode {{{
class BaseNode(object):
  HASH_SIZE = 160
  @classmethod
  def hash(cls, obj):
    return int(hashlib.sha1(obj).hexdigest(), 16)

  @classmethod
  def from_dict(cls, props):
    self = cls(props["ip_address"], props["tcp_port"], props["node_id"])
    return self

  @classmethod
  def from_node(cls, node):
    return cls.from_dict(node.to_dict())

  def __init__(self, ip_address, tcp_port = 10000, node_id = None):
    self.ip_address = ip_address
    self.tcp_port = tcp_port
    self.node_id = node_id or self.__class__.hash(self.id_string())

  def id_string(self):
    return self.ip_address + str(self.tcp_port)

  def __cmp__(self, other):
    return cmp(self.node_id, other.node_id)

  def __eq__(self, other):
    return self.node_id == other.node_id

  def __hash__(self):
    return self.node_id

  def __xor__(self, other):
    return self.node_id ^ getattr(other, "node_id", other)

  def __repr_opt__(self):
    return ""

  def __repr__(self):
    return u"<%s: %s:%d, node_id:%d %s>"%(self.__class__.__name__, self.ip_address, self.tcp_port, self.node_id, self.__repr_opt__())

  def to_json(self):
    return json.dumps(self.to_dict())

  def to_dict(self):
    return {"ip_address":self.ip_address, "tcp_port":self.tcp_port, "node_id": self.node_id}

# }}}

# KademliaNode {{{
CODE_PING_SUCCESS = 1
CODE_FIND_NODES = 2
CODE_FIND_VALUE = 3
CODE_STORE_SUCCESS = 4

class KademliaNode(BaseNode):
  def __init__(self, *args, **kwargs):
    super(KademliaNode, self).__init__(*args, **kwargs)
    self.index_publishing_interval = kwargs.get("index_publishing_interval", 0)
    self.init()

  def init(self):
    self.routing_table = RoutingTable(self)
    self.index = Index(self)
    self.last_index_published = time.time()
    self.tcp_server = TCPServer((self.ip_address, self.tcp_port), self.on_tcp_receive)

  def shutdown(self):
    self.tcp_server.stop()
    self.init()

  def join(self, other_node):
    self.tcp_server.start()
    self.routing_table.learn_new_contact(ContactNode.from_node(other_node))
    self.Join(self.node_id).invoke()

  def to_request(self, data_dict):
    data_dict["from"] = self.to_dict()
    return json.dumps(data_dict)
  to_response = to_request

  def on_tcp_receive(self, message, conn, addresses):
    def find_node(node_id):
      close_nodes = self.routing_table.close_k_contacts(node_id)
      response = {"code":CODE_FIND_NODES, "nodes":[n.to_dict() for n in close_nodes]}
      conn.send(self.to_response(response))

      
    try:
      debug_print(self, "TCP request received:", message)
      data = json.loads(message)   

      m = data["method"]
      contact = ContactNode.from_dict(data["from"])
      try:
        if m == "PING":
          debug_print(self, "PING received: from", data["from"])
          conn.send(self.to_response({"code":CODE_PING_SUCCESS}))

        elif m == "STORE":
          self.index.set_value(data["key"], data["value"])
          conn.send(self.to_response({"code":CODE_STORE_SUCCESS}))

        elif m == "FIND_VALUE":
          try:
            response = {"code":CODE_FIND_VALUE, "value": self.index.get_value(data["key"])}
            conn.send(self.to_response(response))
          except KeyError:
            find_node(data["key"])

        elif m == "FIND_NODE":
          find_node(data["key"])

        self.routing_table.learn_new_contact(contact)
        self.publish_index_if_need()
      except socket.error, e:
        debug_print("on_tcp_receive: socket error: %s"%unicode(e))
        self.routing_table.remove_contact(contact)

    except ValueError, e:
      pass


  def raw_ping(self, other_node):
    debug_print(self, "PING to", other_node)
    message = None
    try:
      sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      sock.connect((other_node.ip_address, other_node.tcp_port))
      sock.send(self.to_request({"method":"PING"}))
      message = sock.recv(8192)
      sock.close()
    except socket.error, e:
      debug_print('PING result: %s' % e)
      return False
    try:
      data = json.loads(message)
      result = data.get("code", None) == CODE_PING_SUCCESS
      debug_print(self, "PING result:", other_node, result)
      return result
    except ValueError, e:
      debug_print(self, "PING result:", other_node, e)
      return False

  def ping(self, other_node):
    result = self.raw_ping(other_node)
    if not result:
      self.routing_table.remove_contact(other_node)
    return result

  class Lookup(object):
    METHOD_NAME = "FIND_NODE"
    NUM_THREAD = 3
    def __init__(self, key):
      self.key = key
      self.node = sys._getframe(1).f_locals["self"]
      self.checked_nodes = {}
      self.checked_lock = threading.Lock()
      self.task_list   = self.node.routing_table.close_k_contacts(self.key)
      self.task_list_lock = threading.Lock()
      self.results = []

    def extend_task_list(self, lst):
      with self.task_list_lock:
        map(self.node.routing_table.learn_new_contact, lst)
        self.task_list.extend(lst)
        self.task_list.sort(cmp=lambda a,b: cmp(a^self.key, b^self.key))

    def get_task(self):
      with self.task_list_lock:
        try:
          result = self.task_list.pop(0)
        except IndexError:
          result = None
      return result

    def pre_process(self, node):
      if node.node_id == self.key:
        self.results.append(node)
        return

    def is_checked(self, node):
      with self.checked_lock:
        is_checked = node in self.checked_nodes
        if not is_checked: self.checked_nodes[node] = True
      return is_checked

    def invoke(self):
      def run(self):
        while True:
          node = self.get_task()
          if not node:
            self.results.append(None)
          else:
            self.pre_process(node)
          if len(self.results): break

          if not self.is_checked(node):
            try:
              sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
              sock.connect((node.ip_address, node.tcp_port))
              sock.send(self.node.to_request({"method":self.METHOD_NAME, "key":self.key}))
              message = sock.recv(8192)
              sock.close()
              try:
                data = json.loads(message)
                self.on_data_received(data)
              except ValueError, e:
                debug_print(self, "Lookup: failed", self.key, e)
            except socket.error, e:
              debug_print(self, 'Connect failed :', node)
              self.node.routing_table.remove_contact(node)

      threads = []
      for i in xrange(self.NUM_THREAD):
        t = threading.Thread(target=run, args=(self,)) 
        t.start()
        threads.append(t)
      for t in threads: t.join()
      
      return self.on_results_received()

    def on_results_received(self):
      try:
        for node in self.results:
          if self.ping(node):
            return node
      except:
        return None
      return None

    def on_data_received(self, data):
      if data.get("code", None) != CODE_FIND_NODES:
        debug_print(self.node, "FIND_NODE: failed", self.key)
        return
      debug_print(self.node, "FIND_NODE_K_NODES:", data["nodes"])
      contacts = [ContactNode.from_dict(d) for d in data["nodes"]]
      self.extend_task_list(contacts)
      
  class FindNode(Lookup): pass
  class Join(Lookup):pass

  class FindValue(Lookup):
    METHOD_NAME="FIND_VALUE"
    def pre_process(self, data):
      pass

    def on_data_received(self, data):
      code = data.get("code")
      if code == CODE_FIND_NODES:
        return super(self.node.FindValue, self).on_data_received(data)
      if code == CODE_FIND_VALUE:
        self.results.append(data["value"])

    def on_results_received(self):
      try:
        return [v for v in self.results][0]
      except IndexError:
        return None

  def find_node(self, key):
    return self.FindNode(key).invoke()
  learn_routing = find_node

  def find_value(self, key):
    return self.FindValue(key).invoke()

  def publish(self, key, value):
    self.learn_routing(key)
    threads = []
    for node in self.routing_table.close_k_contacts(key):
      t = threading.Thread(target=self.store, args = (node, key, value))
      threads.append(t)
      t.start()
    for t in threads: t.join()

  def store(self, node, key, value):
    try:
      debug_print(self, "STORE:", key, "-> ", node)
      sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      sock.connect((node.ip_address, node.tcp_port))
      sock.send(self.to_request({"method":"STORE", "key":key, "value":value}))
      sock.recv(8192)
      sock.close()
    except socket.error,e:
      debug_print(self, "STORE: failed", node, e)
      self.routing_table.remove_contact(node)

  def publish_index_if_need(self):
    if (self.last_index_published + self.index_publishing_interval) > time.time():
      self.last_index_published = time.time()
      for k in self.index:
        threading.Thread(target=self.publish, args = (k, self.index.get_value(k))).start()

# }}}

# ContactNode {{{
class ContactNode(BaseNode):
  def __init__(self, *args, **kwargs):
    self.last_seen = time.time()
    super(ContactNode, self).__init__(*args, **kwargs)
  def __repr_opt__(self):
    return " last_seen:%s"%time.ctime(self.last_seen)
# }}}
