#vim: fileencoding=utf8
# embpy - Embed python code into text.
# Copyright (c) 2009, Yusuke Inuzuka(http://inforno.net/)
#
# License :
#   Artistic License 2.0
#
# Description:
#   The Fast and compact embedded python implementation.
#
#   Template syntax:
#     Strings surrounded by "<%" and "%> is interpretted as a python code. 
#        <% a = 10 %>
#
#     You can use "<%%" as a "<%" itself.
#        <div> <%% </div> ---> <div> <% </div>
#    
#     "<%= python code %>" is replaced by the result of executing "python code".
#    If the "filter" argument is supplied, always apply "filter" to the result.
#    The filter passes a EmbpyString object, subclass of unicode, that is 
#    returned by the Embpy's rendering method. So there is no danger of 
#    the "double-filtering".
#    To turn it off, use "<%=r python code %>". 
#
#        # filter = lambda s: cgi.escape(f)
#        <% a = "<b>" %>
#        <%= a %>  ---> "&lt;b&gt;"
#        <%=r a %> ---> "<b>"
#
#     "<%-" and "-%>", a.k.a "trim mode", can improve on your template code readability.  
#     "<%-" removes spaces in a range from a line head to "<%-".
#     "-%>" removes spaces and a linefeed in a range from "-%>" to a next line head.
#     "end", "{:" ,":}" and "<% %>" are used for a python code indent control. 
#     Parser figure out the indent if the last line of pytnon ends with ":". 
#    Alternatively, explicit indenting is made by "{:"
#     The indent is reset when encountered "end", ":}" or "<% %>".
#
#       <% def a() {: 1; :} %>
#
#       <% def a(): %> 1 <% :} %>
#
#       <% def a(): %> 
#            1 
#       <% end %>
#
#       <% def a(): %> 
#            1 
#            <% %>
#
#       <%- for i in xrange(10): -%>
#         <%= a %>
#         <% %>
#   
#   Rendering:
#     Basics:
#       The first step is to instansiate Embpy objects.
#
#         e = Embpy(template, cache_path, template_globals, filter)
#
#           template : String or File-like object.
#           cache_path: Cache file path. only uses if template is a File like object.
#           template_globals: Dictionary includes Global variables for this template.
#           filter: Filter function.
#
#       and use render(dict) method to render.
#
#         e.render({"varname":value})
#
#     Working with Renderer and Helper:
#       Renderer and Helper are convenient in many cases.
#
#         renderer = Renderer("path_to_template_dir", "path_to_cache_dir", 
#                             template_globals = {"h":Helper()},
#                             filter = Helper.htmlquote)
#         renderer.render_file("index", {"title": "index"})
#         renderer.index({"title": "index"}) # same as above
#         renderer.render_string("<%= v %>", {"v": 10})
#
#       A Helper object has these methods
#           - capture(name): capture the block as "name".
#
#              <% with h.capture("body") %>
#                 foo
#                 <% %>
#              <%= body %>
#
#           - concat(value): concatenate "value" to the output buffer
#
#              <% def print_a() {: h.concat("a") :} %>
#              <% print_a() %>
#
#           - buffer_frame_locals: used as follows
#
#               class MyHelper(embpy.Helper):
#                 @contextlib.contextmanager
#                 def div_tag(self):
#                   with self.capture("__div"):
#                     yield
#                   div = self.buffer_frame_locals["__div"]
#                   self.concat("<div>%s</div>"%div)
#
#               <% with h.div_tag(): %>
#                    text
#                    <% %>
#
# Example1:
#   template.html:
#      <%-
#      class Hoge(object):
#        def __init__(self):
#          pass
#        end
#      end
#      hoge = Hoge()
#      title = "< The times table >"
#      -%>
#      <%=r title %>
#      <%- def format2(v) {: return "%2d"%v; :} -%>
#        <% for y in xrange(1,xx):%><%= format(y) %><% end %>
#      <%- for x in xrange(1,xx): -%>
#      <%= format2(x) -%>
#        <%- for y in xrange(1,xx): -%>
#      <%= format(x*y) -%>
#        <%- end %>
#      <%- end -%>
#
#   code:
#     import embpy
#     template_globals = {
#       "format" : lambda v: "%4d"%v
#     }
#     e = embpy.Embpy(codecs.open("template.html", encoding="utf8"),
#               cache_path = "path_to_cache_file",
#               template_globals = template_globals, filter=embpy.Helper.htmlquote)
#     print e.render({"xx": "10"})
#
#  Example2:
#    templates/index.html:
#      <ul>
#      <%- for i in xrange(max): -%>
#        <%- klass = i%2 and "odd" or "even" -%>
#        <li class="<%= klass %>">
#          <%= renderer.partial({"i":i}) %>
#        </li>
#        <% %>
#      </ul>
#      <% with h.div_tag(): %>
#        hello
#        <% %>
#      <%= renderer.with_layout_file("layout") %>
#
#     templates/partial.html:
#       <%= "%05d"%i -%>
#
#     templates/layout.html:
#       <html>
#       <head>
#       <title><%= title %></title>
#       </head>
#       <body>
#       <%= body %>
#       </body>
#       <html>
#
#     code:
#       import embpy
#       class MyHelper(embpy.Helper):
#         @contextlib.contextmanager
#         def div_tag(self):
#           with self.capture("__div"):
#             yield
#           div = self.captured("__div")
#           self.concat("<div>%s</div>"%div)
#
#       renderer = embpy.Renderer("./templates", "./caches", 
#                                 template_globals = {"h": MyHelper()},
#                                 filter = embpy.Helper.htmlquote,
#                                 encoding = "utf8")
#
#       print renderer.index({"max": 10, "title": "<index page>"})
#     
#
from __future__ import with_statement
__author__  = u"Yusuke Inuzuka"
__version__ = u"1.1.0"
__date__    = u"2009-06-17"

try:
  from re import Scanner
except ImportError:
  from sre import Scanner
import sys, traceback, re, os.path, marshal, threading, codecs, contextlib

# Embpy {{{
class EmbpyString(unicode): pass
class Embpy(object):
  BLOCK_START_PAT = re.compile(r".*:\s*$")

  def _lazy(lock):
    def deco(f):
      v = [None]
      def _(*args):
        lock.acquire()
        if not v[0]: v[0] = f(*args)
        lock.release()
        return v[0]
      return _
    return deco

  @staticmethod
  @_lazy(threading.Lock())
  def scanner():
    # re.Scanner's scan method seems to be thread safe.
    action = lambda token_type: lambda scanner, s: [token_type, s]
    return Scanner([
      (r""""(((?<=\\)")|[^"])*((?<!\\)")""", action("string")),
      (r"""'(((?<=\\)')|[^'])*((?<!\\)')""", action("string")),
      (r"""\s*(else|elif|except|finally)(:|[ \(]("([^\\"]|\\.)*"|'([^\\']|\\.)*'|[^:"'])*[^{]:)""", action("block_keyword")),
      (r"""\{:""", action("indent_start")),
      (r""":\}|([\s]end(?=\s))""", action("indent_end")),
      (r"""^\s*end\s*$""", action("indent_end")),
      (r""";""", action("newline")),
      (r"""(\s(else|elif|except|finally|end))""", action("others")),
      (r"""(?:(?!((\{:|:\}|[\s]end)|(\s(else|elif|except|finally))|[;]))[^"'])*""", action("others")),
    ], re.M|re.S)

  @staticmethod
  @_lazy(threading.Lock())
  def splitter():
    # Searching and matching method on Regular Expression objects are thread safe.
    return re.compile(r"""((?P<print_code><%=(?P<raw_mode>(r )?))|((?P<s_space>^[ \t]*)(?P<trim_start><%\-))|(<%(?!%)(?:\-?)))(?P<code_body>("([^\\"]|\\.)*"|'([^\\']|\\.)*'|(?:(?!(%>)).))*)((?P<trim_end>\-%>[\n]?)|(?P<end_tag>[^%]%>))""", re.M|re.S)


  def __init__(self, template, cache_path = "", template_globals = None, filter=None):
    self.code = ["__buffer= []\n__buffer_append = __buffer.append\n"]
    self.src  = ""
    self.indent = 0
    self.template = getattr(template, "read", lambda: template)()
    self.file_path = getattr(template, "name", None)
    self.encoding = getattr(template, "encoding", None)
    self.cache_path = cache_path
    self.template_globals = template_globals or {}
    self.filter = filter
    if filter:
      def _(s):
        if not isinstance(s, EmbpyString) :
          return filter(unicode(s))
        else:
          return s
      self.template_globals["__filter"] = _

  def is_cached(self):
     return self.file_path and self.cache_path and \
     os.path.exists(self.file_path) and os.path.exists(self.cache_path) and \
     os.path.getmtime(self.file_path) < os.path.getmtime(self.cache_path)

  def compile(self):
    if isinstance(self.code, list):
      if self.is_cached(): 
        self.code = marshal.load(open(self.cache_path, "rb"))
      else:
        s = self.template
        search = self.splitter().search
        scan = self.scanner().scan
        m = True
        pos = 0
        while m:
          m = search(s, pos=pos)
          if m:
            text = s[pos:m.start()]
          else:
            text = s[pos:]
          self.append(self.escape_string(text))
          if not m: break

          d = m.groupdict()
          pos = m.end()
          code_body = [d.get("code_body") or ""]

          if not d.get("trim_end"):
            v = d.get("end_tag")[0]
            if v != "-":
              code_body.append(v)

          if d.get("print_code"):
            self.do_indent()
            if self.filter and not d["raw_mode"]:
              self.code.append(u"__buffer_append(__filter(")
            else:
              self.code.append(u"__buffer_append(unicode(")

          code_body = u"".join(code_body)
          if not code_body.strip():
            # <% %>: indent end
            self.indent_end("")
          else:
            self.do_indent()
            for token_type, value in scan(code_body)[0]:
              getattr(self, token_type)(value)

          if d.get("print_code"):
              self.code.append(u"))")

        self.do_indent()
        self.src = u"".join(self.code)
        try:
          self.code = compile(self.src, "<string>", "exec")
        except SyntaxError,e:
          e.text = u"\n".join(self.src.splitlines()[0:e.lineno])
          e.args = ('invalid syntax', ('<string>', e.lineno, e.offset, e.text))
          raise e, None, sys.exc_info()[-1]
        if self.file_path and self.cache_path:
          marshal.dump(self.code, open(self.cache_path, "wb"))
    return self.code

  def render(self, vars = None):
    vars = vars or {}
    vars.update(self.template_globals)
    try:
      exec self.compile() in vars
    except Exception,e :
      if self.src and not isinstance(e, SyntaxError):
        m = re.match(".*line (\d+).*", traceback.format_exc(2).splitlines()[-2])
        if m:
          line =  int(m.group(1))
          e.message =  "%s\n%s"%(e.args[0], (u"\n".join(self.src.splitlines()[0:line])))
          e.args = [e.message]
      raise e, None, sys.exc_info()[-1]
    return EmbpyString(u"".join(vars["__buffer"]))

  def append(self, s):
    if not s: return
    self.do_indent()
    self.code.append(u"__buffer_append(u\"\"\"%s\"\"\")"%s)

  def do_indent(self, *a):
    self.code.append(u"\n%s"%(u"  "*self.indent))

  def escape_string(self, s):
    return s.replace('"', '\\"').replace("<%%","<%").replace("%%>","%>")

  def others(self, s):
    for line in s.splitlines():
      line_striped = line.lstrip()
      if self.BLOCK_START_PAT.match(line_striped):
        self.code.append(line_striped)
        self.indent += 1
      else:
        self.code.append(line_striped)
      self.do_indent()
    self.code.pop()

  def string(self, s):  self.code.append(s)
  def newline(self, s): self.do_indent()

  def indent_start(self, s):
    self.indent += 1
    self.code.append(u":")
    self.do_indent()

  def indent_end(self, s):
    self.indent -= 1
    self.do_indent()

  def block_keyword(self, s):
    self.indent -= 1
    self.do_indent()
    self.code.append(s.lstrip())
    self.indent += 1
# }}}

# Helper {{{
class Helper(object):
  buffer_search_limit = 10
  def _buffer_frame_locals(self):
    for i in xrange(2, self.buffer_search_limit):
      f = sys._getframe(i).f_locals
      if "__buffer" in f: return f
  buffer_frame_locals = property(_buffer_frame_locals)
  get_buffer_frame_locals = classmethod(_buffer_frame_locals)

  @contextlib.contextmanager
  def capture(self, name):
     locals = self.buffer_frame_locals
     start_index = len(locals["__buffer"])
     yield 
     locals.update({name:EmbpyString(u"".join(locals["__buffer"][start_index:]))})
     del locals["__buffer"][start_index:]

  def concat(self, value):
    self.buffer_frame_locals["__buffer_append"](value)

  def captured(self, value):
    return self.buffer_frame_locals["__buffer"][value]

  def captured(self, value):
    return self.buffer_frame_locals[value]

  @classmethod
  def htmlquote(*a): 
    text = a[-1]
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;").replace('"', "&quot;")
# }}}

# Renderer {{{
class Renderer(object):
  extensions = [".html", ".xml", ".js", ".epy", ".pyhtml"]
  def __init__(self, template_base, cache_base, template_globals = None, filter = None, encoding = "utf8"):
    self.template_base = template_base
    self.cache_base    = cache_base
    self.template_globals = template_globals or {}
    self.template_globals["renderer"] = self
    self.filter = filter
    self.encoding = encoding
    self.embpy_cache = {}

  def create_embpy(self, template, name = ""):
    return Embpy(template,
                cache_path = self.cache_base and os.path.join(self.cache_base, name) or None,
                template_globals = self.template_globals,
                filter = self.filter)

  def render_file(self, name, vars = None, encoding = None):
    template = os.path.join(self.template_base, name)
    if not "." in name:
      for i in self.extensions:
        template_cand = template+i
        if os.path.exists(template_cand):
          template = template_cand
          name = name+i
    embpy = self.embpy_cache.get(template, None)
    if not embpy:
      embpy = self.create_embpy(codecs.open(template, encoding=encoding or self.encoding), name)
      self.embpy_cache[template] = embpy
    return embpy.render(vars or {})
  render = render_file

  def __getattr__(self, name):
    if name.startswith("with_layout"):
      method = "render%s"%name[len("with_layout"):]
      locals = Helper.get_buffer_frame_locals()
      body = EmbpyString(u"".join(locals["__buffer"]))
      locals["__buffer"][:] = []
      locals["body"] = body
      return lambda t, *a, **k: getattr(self, method)(t, locals, *a, **k)
    else:
      return lambda *a, **k: self.render_file(name, *a, **k)

  def render_string(self, template, vars = None):
    return self.create_embpy(template).render(vars or {})
# }}}
